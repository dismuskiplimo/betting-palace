<div class="modal fade" id="update-prediction-modal-<?php echo e($bet->id); ?>" role="dialog">
    <div class="modal-dialog modal-lg modal-dialog-centered text-dark" role ="document">
      <div class="modal-content">
        <form action="<?php echo e(route('analyst.bet.update', ['id' => $bet->id])); ?>" method="POST">
          <?php echo csrf_field(); ?>
          
          <div class="modal-header">
            <h5 class="modal-title">Update Prediction</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          
          <div class="modal-body">
            <div class="row">
              <div class="col-sm-6">
                  <div class="form-group">
                      <label for="">League<span class="text-danger">*</span></label>
                      <input type="text" name="league" value ="<?php echo e($bet->league); ?>" id="" placeholder="league" class="form-control" required = "">
                  </div>
              </div>

              <div class="col-sm-6">
                  <div class="form-group">
                      <label for="">Game ID<span class="text-danger">*</span></label>
                      <input type="number" min="1" value ="<?php echo e($bet->gameId); ?>" name="gameId" class="form-control" required="" id="" placeholder="game id">
                  </div>
              </div>

              
            </div>

            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                    <label for="">Pricing<span class="text-danger">*</span></label>
                    <select name="free" id="" class="form-control" required="">
                      <option value="0"<?php echo e(!$bet->free ? " selected" : ""); ?>>PAID BET</option>
                      <option value="1"<?php echo e($bet->free ? " selected" : ""); ?>>FREE BET</option>
                    </select>
                </div>
              </div>

              <div class="col-sm-6">
                  <div class="form-group">
                    <label for="">Starts at (date hour:min)<span class="text-danger">*</span></label>
                    <div class="row">
                      <div class="col-6">
                        <input type="text" name="starts_at" value="<?php echo e($bet->starts_at ? $bet->starts_at->format('Y-m-d') : ""); ?>" class="form-control datepicker" required="" id="" placeholder="date">
                      </div>

                      <div class="col-3">
                        <select name="hour" id="" class="form-control" required="">
                          <?php for($i = 0; $i < 24; $i++): ?>
                            <option <?php echo e($bet->starts_at->format('H') == $i ? "selected" : ""); ?> value="<?php echo e($i < 10 ? '0' . $i : $i); ?>"><?php echo e($i < 10 ? '0' . $i : $i); ?></option>
                          <?php endfor; ?>
                        </select>
                      </div>

                      <div class="col-3">
                        <select name="minute" id="" class="form-control" required="">
                          <?php for($i = 0; $i<=60; $i++): ?>
                            <option <?php echo e($bet->starts_at->format('i') == $i ? "selected" : ""); ?> value="<?php echo e($i < 10 ? '0' . $i : $i); ?>"><?php echo e($i < 10 ? '0' . $i : $i); ?></option>
                          <?php endfor; ?>
                        </select>
                      </div>
                    </div>
                    
                  </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-6">
                  <div class="form-group">
                      <label for="">Home Team<span class="text-danger">*</span></label>
                      <input type="text" value = "<?php echo e($bet->homeName); ?>" name="homeName" class="form-control" required="" id="" placeholder="home team">
                  </div>
              </div>

              <div class="col-sm-6">
                <div class="form-group">
                    <label for="">Away Team<span class="text-danger">*</span></label>
                    <input type="text"  value = "<?php echo e($bet->awayName); ?>" name="awayName" class="form-control" required="" id="" placeholder="away team">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-4">
                  <div class="form-group">
                      <label for="">Prediction<span class="text-danger">*</span></label>
                      <input type="text" name="prediction" value = "<?php echo e($bet->prediction); ?>" id="" placeholder="prediction" class="form-control" required = "">
                  </div>
              </div>

              <div class="col-sm-4">
                  <div class="form-group">
                      <label for="">Predicted Home Score (optional)</label>
                      <input type="number" min="0" name="predictedHomeScore" value = "<?php echo e($bet->predictedHomeScore); ?>" class="form-control"  id="" placeholder="score">
                  </div>
              </div>

              <div class="col-sm-4">
                <div class="form-group">
                    <label for="">Predicted Away Score (optional)</label>
                    <input type="number" min="0" name="predictedAwayScore" value = "<?php echo e($bet->predictedAwayScore); ?>" class="form-control"  id="" placeholder="score">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-4">
                  <div class="form-group">
                      <label for="">Status<span class="text-danger">*</span></label>
                      <select name="status" class="form-control" id="" required="">
                        <option value="-1" <?php echo e($bet->status == '-1' ? 'selected' : ''); ?>>LOST</option>
                        <option value="0" <?php echo e($bet->status == '0' ? 'selected' : ''); ?>>PENDING</option>
                        <option value="1" <?php echo e($bet->status == '1' ? 'selected' : ''); ?>>WON</option>
                      </select>
                  </div>
              </div>

              <div class="col-sm-4">
                  <div class="form-group">
                      <label for="">Actual Home Score</label>
                      <input type="number" min="0" name="homeScore" value = "<?php echo e($bet->homeScore); ?>" class="form-control"  id="" placeholder="score">
                  </div>
              </div>

              <div class="col-sm-4">
                <div class="form-group">
                    <label for="">Actual Away Score</label>
                    <input type="number" min="0" name="awayScore" value = "<?php echo e($bet->awayScore); ?>" class="form-control"  id="" placeholder="score">
                </div>
              </div>
            </div>

          </div>
          
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-outline-success">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\betting\resources\views/pages/analyst/modals/update-prediction.blade.php ENDPATH**/ ?>