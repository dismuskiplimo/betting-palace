<?php $__env->startSection('content'); ?>
	<?php if(strtolower($salutation) == "admin"): ?>
	<p>New training registration received. Below are the details.</p>
	<?php else: ?>
		<p>Dear <?php echo e($salutation); ?>,</p>
		<p>Your application for <?php echo e($trainingCalendarRegistration->activity); ?> training programme has been received. NCIA will revied the details and contact you in due time.</p>
	<?php endif; ?>

	
	<table class = "table table-striped">
		<tr>
			<th>Title</th>
			<td><?php echo e($trainingCalendarRegistration->training_calendar->activity); ?></td>
		</tr>
		
		<tr>
			<th>First Name</th>
			<td><?php echo e($trainingCalendarRegistration->first_name); ?></td>
		</tr>

		<tr>
			<th>Middle Name</th>
			<td><?php echo e($trainingCalendarRegistration->middle_name); ?></td>
		</tr>

		<tr>
			<th>Last Name</th>
			<td><?php echo e($trainingCalendarRegistration->last_name); ?></td>
		</tr>

		<tr>
			<th>Telephone</th>
			<td><?php echo e($trainingCalendarRegistration->telephone); ?></td>
		</tr>

		<tr>
			<th>Gender</th>
			<td><?php echo e($trainingCalendarRegistration->gender); ?></td>
		</tr>

		<tr>
			<th>Address</th>
			<td><?php echo e($trainingCalendarRegistration->address); ?></td>
		</tr>

		<tr>
			<th>Postal Code</th>
			<td><?php echo e($trainingCalendarRegistration->postal_code); ?></td>
		</tr>

		<tr>
			<th>Town/City</th>
			<td><?php echo e($trainingCalendarRegistration->city); ?></td>
		</tr>

		<tr>
			<th>Mobile</th>
			<td><?php echo e($trainingCalendarRegistration->mobile); ?></td>
		</tr>

		<tr>
			<th>Email</th>
			<td><?php echo e($trainingCalendarRegistration->email); ?></td>
		</tr>

		<tr>
			<th>Firm</th>
			<td><?php echo e($trainingCalendarRegistration->firm); ?></td>
		</tr>

		<tr>
			<th>Bank Transfer Date</th>
			<td><?php echo e($trainingCalendarRegistration->bank_transfer_date); ?></td>
		</tr>

		<tr>
			<th>Payment Method</th>
			<td><?php echo e($trainingCalendarRegistration->payment_method); ?></td>
		</tr>

		<tr>
			<th>Receipt_no</th>
			<td><?php echo e($trainingCalendarRegistration->receipt_no); ?></td>
		</tr>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/emails/training-registration-received.blade.php ENDPATH**/ ?>