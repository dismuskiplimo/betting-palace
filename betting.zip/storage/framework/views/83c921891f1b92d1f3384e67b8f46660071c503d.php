<?php $__env->startSection('content'); ?>
	<?php if(strtolower($salutation) == "admin"): ?>
	<p>New booking request for <?php echo e($booking->room->room_name); ?> received. Below are the details.</p>
	<?php else: ?>
		<p>Dear <?php echo e($salutation); ?>,</p>
		<p>Your booking request for <?php echo e($booking->room->room_name); ?> has been received. NCIA will review the details and contact you in due time. Below are the details that you sumitted.</p>
	<?php endif; ?>

	
	<table class = "table table-striped">
		<tr>
			<th>Room</th>
			<td><?php echo e($booking->room->room_name); ?></td>
		</tr>
		
		<tr>
			<th>Duration</th>
			<td><?php echo e($booking->duration()); ?></td>
		</tr>

		<tr>
			<th>From</th>
			<td><?php echo e($booking->from->toFormattedDateString()); ?></td>
		</tr>

		<tr>
			<th>To</th>
			<td><?php echo e($booking->to->toFormattedDateString()); ?></td>
		</tr>

		<tr>
			<th>Number of Participants</th>
			<td><?php echo e($booking->no_of_participants); ?></td>
		</tr>

		<tr>
			<th>Name of organization\entity</th>
			<td><?php echo e($booking->organization); ?></td>
		</tr>

		<tr>
			<th>Nature of Session</th>
			<td><?php echo e($booking->nature_of_session); ?></td>
		</tr>

		<tr>
			<th>Contact Name</th>
			<td><?php echo e($booking->contact_name); ?></td>
		</tr>

		<tr>
			<th>Telephone</th>
			<td><?php echo e($booking->telephone); ?></td>
		</tr>

		<tr>
			<th>Email</th>
			<td><?php echo e($booking->email); ?></td>
		</tr>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/emails/booking-received.blade.php ENDPATH**/ ?>