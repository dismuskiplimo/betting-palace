<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="mt-5 text-center"><?php echo e($title); ?></h2>

            <div class="row text-center">
                <div class="title-separator theme-bg-blue"></div>
            </div>

            <form action="" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/pages/request-for-service.blade.php ENDPATH**/ ?>