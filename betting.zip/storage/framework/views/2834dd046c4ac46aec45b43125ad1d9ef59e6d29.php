<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="mt-5 text-center"><?php echo e($title); ?></h2>

            <div class="row text-center">
                <div class="title-separator theme-bg-blue"></div>
            </div>

            <form action="" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="card border-primary mt-2">
                    <div class="card-body">
                        <h4>CLAIMANT'S REPRESENTATIVE</h4>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">Name<span class="text-danger">*</span></label>
                                    <input type="text" name="claimant_name" class="form-control" required="" placeholder="name" value="<?php echo e(old('claimant_name')); ?>">
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="">Telephone<span class="text-danger">*</span></label>
                                    <input type="text" name="claimant_telephone" class="form-control" required="" placeholder="telephone" value="<?php echo e(old('claimant_telephone')); ?>">
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="">Fax</label>
                                    <input type="text" name="claimant_fax" class="form-control" placeholder="fax" value="<?php echo e(old('claimant_fax')); ?>">
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">Email<span class="text-danger">*</span></label>
                                    <input type="email" name="claimant_email" class="form-control" required="" placeholder="email" value="<?php echo e(old('claimant_email')); ?>">
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="card border-primary mt-2">
                    <div class="card-body">
                        <h4>RESPONDENT'S REPRESENTATIVE</h4>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">Name<span class="text-danger">*</span></label>
                                    <input type="text" name="respondent_name" class="form-control" required="" placeholder="name" value="<?php echo e(old('respondent_name')); ?>">
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="">Telephone<span class="text-danger">*</span></label>
                                    <input type="text" name="respondent_telephone" class="form-control" required="" placeholder="telephone" value="<?php echo e(old('respondent_telephone')); ?>">
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="">Fax</label>
                                    <input type="text" name="respondent_fax" class="form-control" placeholder="fax" value="<?php echo e(old('respondent_fax')); ?>">
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">Email<span class="text-danger">*</span></label>
                                    <input type="email" name="respondent_email" class="form-control" required="" placeholder="email" value="<?php echo e(old('respondent_email')); ?>">
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="card border-primary mt-2">
                    <div class="card-body">
                        <h4>DISPUTE DETAILS</h4>

                        <div class="row">
                           

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">1. Brief explanation of the nature of dispute, 
                                        the amount involved, if any, and the specific 
                                        relief sought.<span class="text-danger">*</span></label>
                                    <textarea rows="10" type="text" name="nature_of_dispute" class="form-control" required="" placeholder="nature of dispute"><?php echo e(old('nature_of_dispute')); ?></textarea>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">2. Reference to a mediation clause in the manner
                                        specified in Part A set out in the First Schedule
                                        or a copy of the separate mediation agreement.<span class="text-danger">*</span></label>
                                    <textarea rows="10" type="text" name="mediation_clause" class="form-control" required="" placeholder="enter here"><?php echo e(old('mediation_clause')); ?></textarea>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">3. Reference to the contract or other legal 
                                        relationship out of or in relation to which the 
                                        dispute arises.<span class="text-danger">*</span></label>
                                    <textarea rows="10" type="text" name="contract" class="form-control" required="" placeholder="enter here"><?php echo e(old('contract')); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12"> 
                                <p>
                                    NB: Application must be accompanied by a non-refundable fee as prescribed in the Fee Schedule
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
                
                <p class="mt-3"><span class="text-danger">*</span> Required</p>
                <button type="submit" class="btn btn-primary">Submit</button>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/pages/request-for-mediation.blade.php ENDPATH**/ ?>