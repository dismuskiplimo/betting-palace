<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row my-5">
            <div class="col-sm-3"><?php echo $__env->make('pages.admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="col-sm-9">
                <h4 class="text-warning mb-3"><?php echo e($title); ?></h4>

                <h5>Personal Information</h5>
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" class="form-control" name="name" placeholder="name" value="<?php echo e(auth()->user()->name); ?>" required="" id="">
                    </div>

                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" class="form-control" name="email" placeholder="email" value="<?php echo e(auth()->user()->email); ?>" required="" id="">
                    </div>

                    <div class="form-group">
                        <label for="">Phone</label>
                        <input type="number" class="form-control" name="phone" placeholder="phone" value="<?php echo e(auth()->user()->phone); ?>" required="" id="">
                    </div>

                    <div class="rogm-group">
                        <button type="submit" class="btn btn-warning">UPDATE</button>
                    </div>
                </form>

                <h5 class="mt-5">Update Password</h5>
                <form action="<?php echo e(route('auth.password.update')); ?>" method="POST" class="">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Old Password</label>
                        <input type="password" class="form-control" name="old_password" placeholder="old password" required="" id="">
                    </div>

                    <div class="form-group">
                        <label for="">New Password</label>
                        <input type="password" class="form-control" name="new_password" placeholder="new password" required="" id="">
                    </div>

                    <div class="form-group">
                        <label for="">Confirm New Password</label>
                        <input type="password" class="form-control" name="new_password_confirmation" placeholder="confirm new password" required="" id="">
                    </div>

                    <div class="rogm-group">
                        <button type="submit" class="btn btn-warning">UPDATE</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <?php echo $__env->make('pages.standard-user.modals.make-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pages.standard-user.modals.make-sms-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/admin/settings.blade.php ENDPATH**/ ?>