<!doctype html>
<html>
	<head>
		<title></title>
		<meta charset = "utf-8">
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		
		<?php echo $__env->make('includes.email.bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('includes.email.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
	</head>
	<body>
		<?php /**PATH C:\wamp64\www\ncia\resources\views/includes/email/header.blade.php ENDPATH**/ ?>