<?php $__env->startSection('content'); ?>
	<?php if(strtolower($salutation) == "admin"): ?>
	<p>An arbitration request has been received. Below are the details.</p>
	<?php else: ?>
		<p>Dear <?php echo e($salutation); ?>,</p>
		<p>Your request for arbitrtion has been received. NCIA will review the application and contact you in due time. Below is a copy of the application details you provided.</p>
	<?php endif; ?>

	<p><strong>1. Claimant's Representative</strong></p>
	
	<table class = "table table-striped">
		<tr>
			<th>Name</th>
			<td><?php echo e($request->claimant_name); ?> panel status</td>
		</tr>
		
		<tr>
			<th>Telephone</th>
			<td><?php echo e($request->claimant_telephone); ?></td>
		</tr>

		<tr>
			<th>Fax</th>
			<td><?php echo e($request->claimant_fax); ?></td>
		</tr>

		<tr>
			<th>Email</th>
			<td><a href="mailto:<?php echo e($request->claimant_email); ?>"><?php echo e($request->claimant_email); ?></a></td>
		</tr>
	</table>
	

	<p><strong>2. Respondent's Representative</strong></p>
	
	<table class = "table table-striped">
		<tr>
			<th>Name</th>
			<td><?php echo e($request->respondent_name); ?> panel status</td>
		</tr>
		
		<tr>
			<th>Telephone</th>
			<td><?php echo e($request->respondent_telephone); ?></td>
		</tr>

		<tr>
			<th>Fax</th>
			<td><?php echo e($request->respondent_fax); ?></td>
		</tr>

		<tr>
			<th>Email</th>
			<td><a href="mailto:<?php echo e($request->respondent_email); ?>"><?php echo e($request->respondent_email); ?></a></td>
		</tr>
	</table>

	<p><strong>3. Dispute Details</strong></p>
	
	<table class = "table table-striped">
		<tr>
			<th>1. Brief explanation of the nature of dispute, the amount involved, if any, and the specific relief sought</th>
			<td><?php echo e($request->nature_of_dispute); ?></td>
		</tr>
		
		<tr>
			<th>2. Reference to a mediation clause in the manner specified in Part A set out in the First Schedule or a copy of the separate mediation agreement.</th>
			<td><?php echo e($request->mediation_clause); ?></td>
		</tr>

		<tr>
			<th>3. Reference to the contract or other legal relationship out of or in relation to which the dispute arises.</th>
			<td><?php echo e($request->contract); ?></td>
		</tr>
	</table>

	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/emails/mediation-request-received.blade.php ENDPATH**/ ?>