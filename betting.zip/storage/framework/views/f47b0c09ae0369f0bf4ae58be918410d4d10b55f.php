<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row my-5">
            <div class="col-sm-8 offset-sm-2">
                <h4 class="text-warning mb-5"><?php echo e($title); ?></h4>

                <h5>Current Subscription</h5>

                <?php if($user->subscription_active()): ?>
                    <p>Subscription Type: <?php echo e($user->subscription()->subscription_details); ?></p>
                    <p>Active Until: <?php echo e($user->subscription()->ends_at->toDayDateTimeString()); ?></p>
                    <p>Amount Paid: KES <?php echo e(number_format($user->subscription()->mpesa_amount)); ?>/=</p>
                <?php else: ?>
                    <p>Free Subscription (You are only able to view free tips)</p>
                    <p>
                        <a class="btn btn-sm btn-outline-warning" href="" data-toggle="modal" data-target="#make-subscription-modal">SUBSCRIBE NOW</a>
                    </p>
                <?php endif; ?>

                <hr style="border-color: aliceblue">

                <h5>SMS Notifications</h5>

                <?php if($user->subscription_active()): ?>
                    <?php if($user->sms_subscription_active()): ?>
                        <p>Description: <?php echo e($user->sms_subscription()->subscription_details); ?></p>
                        <p>Active Until: <?php echo e($user->sms_subscription()->ends_at->toDayDateTimeString()); ?></p>
                        <p>Amount Paid: KES <?php echo e(number_format($user->sms_subscription()->mpesa_amount)); ?>/=</p>
                    <?php else: ?>
                    <a class="btn btn-sm btn-outline-warning" href="" data-toggle="modal" data-target="#make-sms-subscription-modal">SUBSCRIBE TO SMS</a>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <p>First subscribe to premium before you can enable SMS notifications</p>
                <?php endif; ?>

                

            </div>
        </div>
    </div>
    <?php echo $__env->make('pages.standard-user.modals.make-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pages.standard-user.modals.make-sms-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/standard-user/subscriptions.blade.php ENDPATH**/ ?>