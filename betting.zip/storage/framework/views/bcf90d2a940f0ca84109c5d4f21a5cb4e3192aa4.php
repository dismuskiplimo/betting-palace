<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="col-sm-12">
                <h4 class="text-warning"><?php echo e($title); ?></h4>

                <hr>

                <table class="table table-dark table-striped">
                    <thead>
                        <tr class="text-warning">
                            <th>Time</th>
                            <th>League</th>
                            <th>GameId</th>
                            <th>Home</th>
                            <th>Away</th>
                            <th>Predicted Score</th>
                            <th>Actual Score</th>
                            <th>Prediction (Tip)</th>
                            <th>Bet Status</th>
                            <th></th>
                            
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr <?php echo $bet->status == 1 ? ' class="bg-success"' : ' class="bg-danger"'; ?>>
                                <td><?php echo e($bet->starts_at->toDayDateTimeString()); ?></td>
                                <td><?php echo e($bet->league); ?></td>
                                <td><?php echo e($bet->gameId); ?></td>
                                <td><?php echo e($bet->homeName); ?></td>
                                <td><?php echo e($bet->awayName); ?></td>
                                <td><?php echo e($bet->predictedHomeScore ? : '' . ' - ' . $bet->predictedAwayScore? : ''); ?></td>
                                <td><?php echo e($bet->homeScore .' - '. $bet->awayScore); ?></td>
                                <td><?php echo e($bet->prediction); ?></td>
                                <td><?php echo $bet->status == 1 ? 'WON' : 'LOST'; ?></td>
                                <td><?php echo $bet->free ? '<span class="text-muted">FREE</span>' : '<span class="text-warning"><i class = "fas fa-star"></i> PREMIUM</span>'; ?></td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo e($bets->links()); ?>

            </div>
        </div>
    </div>
    <?php echo $__env->make('pages.standard-user.modals.make-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pages.standard-user.modals.make-sms-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/standard-user/history.blade.php ENDPATH**/ ?>