<div class="list-group bg-dark">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.dashboard" ? "active" : ""); ?>" aria-current="true">Dashboard</a>
    <a href="<?php echo e(route('admin.predictions', ['type' => 'active'])); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.predictions" ? "active" : ""); ?>">Bet Predictions</a>
    <a href="<?php echo e(route('admin.bet-groups', ['type' => 'active'])); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.bet-groups" ? "active" : ""); ?>">Bet Groups</a>
    <a href="<?php echo e(route('admin.subscriptions', ['type' => 'active'])); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.subscriptions" ? "active" : ""); ?>">Bet Subscriptions</a>
    <a href="<?php echo e(route('admin.sms-subscriptions', ['type' => 'active'])); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.sms-subscriptions" ? "active" : ""); ?>">SMS Subscriptions</a>
    <a href="<?php echo e(route('admin.transactions', ['type' => 'all'])); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.transactions" ? "active" : ""); ?>">Transactions</a>
    <a href="<?php echo e(route('admin.users', ['type' => 'active'])); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.users" ? "active" : ""); ?>">Users</a>
    <a href="<?php echo e(route('admin.site-settings')); ?>" class="list-group-item list-group-item-action list-group-item-dark <?php echo e(isset($nav) && $nav == "admin.site-settings" ? "active" : ""); ?>">Site Settings</a>
    <a href="<?php echo e(route('logout')); ?>" class="list-group-item list-group-item-action list-group-item-dark">Logout</a>
    
</div>
<?php /**PATH C:\wamp64\www\betting\resources\views/pages/admin/includes/sidebar.blade.php ENDPATH**/ ?>