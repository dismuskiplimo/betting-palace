<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="col-sm-3"><?php echo $__env->make('pages.admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="col-sm-9">
                <h4 class="text-warning mb-3"><?php echo e($title); ?>

                    <div class="btn-group float-right" role="group" aria-label="Basic example">
                        <a href="<?php echo e(route('admin.predictions', ['category' => 'all'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'all' ? ' active' : ''); ?>">All</a>
                        <a href="<?php echo e(route('admin.predictions', ['category' => 'active'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'active' ? ' active' : ''); ?>">Active</a>
                        <a href="<?php echo e(route('admin.predictions', ['category' => 'premium'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'premium' ? ' active' : ''); ?>">Premium</a>
                        <a href="<?php echo e(route('admin.predictions', ['category' => 'free'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'free' ? ' active' : ''); ?>">Free</a>
                        <a href="<?php echo e(route('admin.predictions', ['category' => 'won'])); ?>" class="btn btn-sm btn-outline-warning"<?php echo e($category == 'won' ? ' active' : ''); ?>>Won</a>
                        <a href="<?php echo e(route('admin.predictions', ['category' => 'lost'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'lost' ? ' active' : ''); ?>">Lost</a>
                    </div>
                </h4>

                <table class="table table-dark table-striped" style="font-size:.7rem">
                    <thead>
                        <tr class="text-warning">
                            <th>Time</th>
                            <th>League</th>
                            <th>GameId</th>
                            <th>Home</th>
                            <th>Away</th>
                            <th>Prediction (Tip)</th>
                            <th>Predicted Score</th>
                            <th>Result</th>
                            <th>Price</th>
                            <th>Added By</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bet->starts_at->toDayDateTimeString()); ?></td>
                                <td><?php echo e($bet->league); ?></td>
                                <td><?php echo e($bet->gameId); ?></td>
                                <td><?php echo e($bet->homeName); ?></td>
                                <td><?php echo e($bet->awayName); ?></td>
                                <td><?php echo e($bet->prediction); ?></td>
                                <td><?php echo e($bet->predictedHomeScore != null && $bet->predictedAwayScore != null ? $bet->predictedHomeScore . ' - ' . $bet->predictedAwayScore : '-'); ?></td>
                                <td>
                                    <?php if($bet->status == -1): ?>
                                        <span class="text-danger">LOST(<?php echo e($bet->homeScore . '-' . $bet->awayScore); ?>)</span>
                                    <?php elseif($bet->status == 0): ?>
                                        <span class="text-muted">PENDING</span>
                                    <?php else: ?>
                                    <span class="text-success">WON(<?php echo e($bet->homeScore . '-' . $bet->awayScore); ?>)</span>
                                    <?php endif; ?>
                                </td>

                                <td><?php echo $bet->free ? '<span class="text-muted">FREE</span>' : '<span class="text-warning">PREMIUM</span>'; ?></td>
                                <td><?php echo e($bet->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo e($bets->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/admin/predictions.blade.php ENDPATH**/ ?>