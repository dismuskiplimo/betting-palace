<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row my-5">
        <div class="col-sm-12">
            <h4 class="text-warning">Today's Free Picks
                <a href="" data-toggle="modal" data-target="#add-prediction-modal" class="btn btn-warning btn-sm float-right">ADD PREDICTION</a>
                <a href="" data-toggle="modal" data-target="#create-grouping-modal" class="btn btn-warning btn-sm float-right mr-2">CREATE GROUPING</a>
                <a href="" data-toggle="modal" data-target="#send-sms-modal" class="btn btn-warning btn-sm float-right mr-2">SEND SMS</a>
            </h4>

            <hr>

            <table class="table table-dark table-striped">
                <thead>
                    <tr class="text-warning">
                        <th>Time</th>
                        <th>League</th>
                        <th>GameId</th>
                        <th>Home</th>
                        <th>Away</th>
                        <th>Prediction (Tip)</th>
                        <th>Predicted Score</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $free_bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($bet->starts_at->toDayDateTimeString()); ?></td>
                            <td><?php echo e($bet->league); ?></td>
                            <td><?php echo e($bet->gameId); ?></td>
                            <td><?php echo e($bet->homeName); ?></td>
                            <td><?php echo e($bet->awayName); ?></td>
                            <td><?php echo e($bet->prediction); ?></td>
                            <td><?php echo e($bet->predictedHomeScore != null && $bet->predictedAwayScore != null ? $bet->predictedHomeScore . ' - ' . $bet->predictedAwayScore : '-'); ?></td>
                            <th>
                                <a href="" title="update prediction" class = "text-info" data-toggle="modal" data-target="#update-prediction-modal-<?php echo e($bet->id); ?>"><i class="fas fa-edit"></i></a>
                                <a href="" title = "delete prediction" class = "text-danger" data-toggle="modal" data-target="#delete-prediction-modal-<?php echo e($bet->id); ?>"><i class="fas fa-trash"></i></a>


                                <?php echo $__env->make('pages.analyst.modals.update-prediction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('pages.analyst.modals.delete-prediction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="col-sm-12 mt-5">
            
            <h4 class="text-warning">Paid Predictions</h4>

            <hr>

            <table class="table table-dark table-striped">
                <thead>
                    <tr class="text-warning">
                        <th>Time</th>
                        <th>League</th>
                        <th>GameId</th>
                        <th>Home</th>
                        <th>Away</th>
                        <th>Prediction (Tip)</th>
                        <th>Predicted Score</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $paid_bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($bet->starts_at->toDayDateTimeString()); ?></td>
                            <td><?php echo e($bet->league); ?></td>
                            <td><?php echo e($bet->gameId); ?></td>
                            <td><?php echo e($bet->homeName); ?></td>
                            <td><?php echo e($bet->awayName); ?></td>
                            <td><?php echo e($bet->prediction); ?></td>
                            <td><?php echo e($bet->predictedHomeScore != null && $bet->predictedAwayScore != null ? $bet->predictedHomeScore . ' - ' . $bet->predictedAwayScore : '-'); ?></td>
                            <td>
                                <a href="" title="update prediction" class = "text-info" data-toggle="modal" data-target="#update-prediction-modal-<?php echo e($bet->id); ?>"><i class="fas fa-edit"></i></a>
                                <a href="" title = "delete prediction" class = "text-danger" data-toggle="modal" data-target="#delete-prediction-modal-<?php echo e($bet->id); ?>"><i class="fas fa-trash"></i></a>


                                <?php echo $__env->make('pages.analyst.modals.update-prediction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('pages.analyst.modals.delete-prediction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                        </tr>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="col-sm-12 mt-5">
            
            <h4 class="text-warning">Premium hand-picked groupings</h4>

            <hr>

            <?php $i = 1;  ?>

            <?php $__currentLoopData = $bet_slips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $betslip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 class="text-warning">Group <?php echo e($i); ?>

                    <a href="" title = "delete bet group" class = "text-danger float-right" data-toggle="modal" data-target="#delete-betslip-modal-<?php echo e($betslip->id); ?>"><i class="fas fa-trash"></i></a>

                    <?php echo $__env->make('pages.analyst.modals.delete-betslip', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </h5>
                <?php $i += 1;  ?>
        
                <table class="table table-dark table-striped">
                    <thead>
                        <tr class="text-warning">
                            <th>Time</th>
                            <th>League</th>
                            <th>GameId</th>
                            <th>Home</th>
                            <th>Away</th>
                            <th>Prediction (Tip)</th>
                            <th>Predicted Score</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $betslip->bets()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $bet = $bet->bet;  ?>
                            <tr>
                                <td><?php echo e($bet->starts_at->toDayDateTimeString()); ?></td>
                                <td><?php echo e($bet->league); ?></td>
                                <td><?php echo e($bet->gameId); ?></td>
                                <td><?php echo e($bet->homeName); ?></td>
                                <td><?php echo e($bet->awayName); ?></td>
                                <td><?php echo e($bet->prediction); ?></td>
                                <td><?php echo e($bet->predictedHomeScore != null && $bet->predictedAwayScore != null ? $bet->predictedHomeScore . ' - ' . $bet->predictedAwayScore : '-'); ?></td>
                                <td>
                                    <a href="" title="update prediction" class = "text-info" data-toggle="modal" data-target="#update-prediction-modal-<?php echo e($bet->id); ?>"><i class="fas fa-edit"></i></a>
                                    <a href="" title = "delete prediction" class = "text-danger" data-toggle="modal" data-target="#delete-prediction-modal-<?php echo e($bet->id); ?>"><i class="fas fa-trash"></i></a>


                                    <?php echo $__env->make('pages.analyst.modals.update-prediction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('pages.analyst.modals.delete-prediction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php echo $__env->make('pages.analyst.modals.add-prediction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.analyst.modals.create-grouping', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.analyst.modals.send-sms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/analyst/index.blade.php ENDPATH**/ ?>