hbhbbhbh@extends('layouts.email')

<?php $__env->startSection('content'); ?>
	<?php if(strtolower($salutation) == "admin"): ?>
	<p>A new <?php echo e($panel->panel_type); ?> panel status application has been received. Below are the details.</p>
	<?php else: ?>
		<p>Dear <?php echo e($salutation); ?>,</p>
		<p>Your <?php echo e($panel->panel_type); ?> panel status application has been received. NCIA will review the application and contact you in due time. Below is a copy of the application details you provided.</p>
	<?php endif; ?>

	<p><strong>1. Personal Information</strong></p>
	<table class = "table table-striped">
		<tr>
			<th>Panel</th>
			<td><?php echo e(ucfirst($panel->panel_type)); ?> panel status</td>
		</tr>
		
		<tr>
			<th>First Name</th>
			<td><?php echo e($panel->first_name); ?></td>
		</tr>

		<tr>
			<th>Middle Name</th>
			<td><?php echo e($panel->middle_name); ?></td>
		</tr>

		<tr>
			<th>Last Name</th>
			<td><?php echo e($panel->last_name); ?></td>
		</tr>

		<tr>
			<th>Panel Category</th>
			<td><?php echo e(ucfirst($panel->panel_category) . ' ' . $panel->panel_type); ?></td>
		</tr>

		<tr>
			<th>Nationality</th>
			<td><?php echo e($panel->nationality); ?></td>
		</tr>

		<tr>
			<th>ID/Pssport Number</th>
			<td><?php echo e($panel->id_no); ?></td>
		</tr>

		<tr>
			<th>Other Nationality</th>
			<td><?php echo e($panel->other_nationality); ?></td>
		</tr>

		<tr>
			<th>Other ID/Pssport Number</th>
			<td><?php echo e($panel->other_id_no); ?></td>
		</tr>

		<tr>
			<th>Mailing/Physical Address</th>
			<td><?php echo e($panel->mailing_address); ?></td>
		</tr>

		<tr>
			<th>Firm</th>
			<td><?php echo e($panel->firm); ?></td>
		</tr>

		<tr>
			<th>Mailing country</th>
			<td><?php echo e($panel->mailing_country); ?></td>
		</tr>

		<tr>
			<th>City</th>
			<td><?php echo e($panel->city); ?></td>
		</tr>

		<tr>
			<th>Postal code</th>
			<td><?php echo e($panel->postal_code); ?></td>
		</tr>

		<tr>
			<th>Telephone</th>
			<td><a href="tel:<?php echo e($panel->phone); ?>"></a><?php echo e($panel->phone); ?></td>
		</tr>

		<tr>
			<th>Fax</th>
			<td><?php echo e($panel->fax); ?></td>
		</tr>

		<tr>
			<th>Email</th>
			<td><a href="mailto:<?php echo e($panel->email); ?>"></a><?php echo e($panel->email); ?></td>
		</tr>

		<tr>
			<th>Primary occupation</th>
			<td><?php echo e($panel->occupation); ?></td>
		</tr>
	</table>

	<p><strong>2. Education</strong></p>
	
	<p>i) Academic Qualifications</p>
	
	<?php if($panel->academicQualifications()->count()): ?>
		<table class = "table table-striped">
			<thead>
				<th>Year Awarded</th>
				<th>Degree/Certificate</th>
				<th>Institution</th>
			</thead>

			<tbody>
				<?php $__currentLoopData = $panel->academicQualifications()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academicQualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($academicQualification->year); ?></td>
						<td><?php echo e($academicQualification->degree); ?></td>
						<td><?php echo e($academicQualification->institution); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	<?php else: ?>
		<p class="text-muted">None</p>
	<?php endif; ?>

	<p>ii) Mediation Training</p>
	
	<?php if($panel->training()->count()): ?>
		<table class="table table-striped">
			<thead>
				<th>Year Awarded</th>
				<th>Nature of training</th>
				<th>Institution</th>
			</thead>

			<tbody>
				<?php $__currentLoopData = $panel->training()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($training->year); ?></td>
						<td><?php echo e($training->nature); ?></td>
						<td><?php echo e($training->institution); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	<?php else: ?>
		<p class="text-muted">None</p>
	<?php endif; ?>

	<p>iii) Other Training</p>

	<?php if($panel->otherTraining()->count()): ?>
		<table class = "table table-striped">
			<thead>
				<th>Year Awarded</th>
				<th>Nature of training</th>
				<th>Institution</th>
			</thead>

			<tbody>
				<?php $__currentLoopData = $panel->otherTraining()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($training->year); ?></td>
						<td><?php echo e($training->nature); ?></td>
						<td><?php echo e($training->institution); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	<?php else: ?>
		<p class="text-muted">None</p>
	<?php endif; ?>

	<p><strong>3. <?php echo e($panel->panel_type == 'arbitrator' ? 'Arbitration' : 'Mediation'); ?> Experience</strong></p>

	<table class="table table-striped">
		<thead>
			<th></th>
			<th>Commercial</th>
			<th>Construction</th>
			<th>Investor/State</th>
			<th>Other(Special)</th>
		</thead>

		<tbody>
			<tr>
				<th>Sole <?php echo e($panel->panel_type); ?></th>
				<td><?php echo e($panel->sole_commercial); ?></td>
				<td><?php echo e($panel->sole_construction); ?></td>
				<td><?php echo e($panel->sole_investor); ?></td>
				<td><?php echo e($panel->sole_other); ?></td>
			</tr>

			<tr>
				<th><?php echo e($panel->panel_type == 'arbitrator' ? 'Member arbitrator panel' : 'Co-mediator'); ?></th>
				<td><?php echo e($panel->member_commercial); ?></td>
				<td><?php echo e($panel->member_construction); ?></td>
				<td><?php echo e($panel->member_investor); ?></td>
				<td><?php echo e($panel->member_other); ?></td>
			</tr>

			<tr>
				<th>Counsel/Agent</th>
				<td><?php echo e($panel->counsel_commercial); ?></td>
				<td><?php echo e($panel->counsel_construction); ?></td>
				<td><?php echo e($panel->counsel_investor); ?></td>
				<td><?php echo e($panel->counsel_other); ?></td>
			</tr>
		</tbody>
	</table>

	<p><strong>4. Disputes handled</strong></p>

	<?php if($panel->disputes()->count()): ?>
		<table class = "table table-striped">
			<thead>
				<th>Type of dispute</th>
				<th>Issues</th>
				<th>Value of dispute</th>
				<th>Nature of evidence</th>
				<th>Duration of dispute</th>
			</thead>

			<tbody>
				<?php $__currentLoopData = $panel->disputes()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($dispute->type); ?></td>
						<td><?php echo e($dispute->issue); ?></td>
						<td><?php echo e($dispute->value); ?></td>
						<td><?php echo e($dispute->evidence); ?></td>
						<td><?php echo e($dispute->duration); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	<?php else: ?>
		<p class="text-muted">None</p>
	<?php endif; ?>

	<p>- Number of years you have acted as an Arbitrator: <?php echo e($panel->years_acted); ?></p>
	<p>- Certified/accredited <?php echo e(ucfirst($panel->panel_type)); ?> or listed in the panel of any other <?php echo e($panel->panel_type == 'arbitration' ? 'arbitral/Arbitration' : 'mediation'); ?> institution? <?php echo e($panel->certified ? 'Yes' : 'No'); ?></p>
	<p>- Certification particulars: <?php echo e($panel->certified_particulars); ?></p>
	<p>- <?php echo e($panel->panel_type == 'arbitrator' ? 'Arbitration' : 'Mediation'); ?> is primary practice? <?php echo e($panel->primary_practice ? 'Yes' : 'No'); ?></p>

	<?php if($panel->panel_type == 'arbitration'): ?>
		<p>- willing to be appointed as an Emergency Arbitrator? <?php echo e($panel->willing_to_be_emergency_arbitrator ? 'Yes' : 'No'); ?></p>
		<p>- Emergency arbitrator contact details</p>
		<p>- Tel No. <?php echo e($panel->emergency_tel_no); ?></p>
		<p>- Email Address <?php echo e($panel->emergency_email); ?></p>
		<p>- Physical Address <?php echo e($panel->emergency_physical_address); ?></p>
	<?php endif; ?>

	<p><strong>Other Information</strong></p>
	<p>i) Relevant Experience <br><?php echo e($panel->relevant_expereince); ?></p>
	<p>ii) Preferred areas of practice as a(n) <?php echo e(ucfirst($panel->panel_type)); ?> <br><?php echo e($panel->preferred_areas); ?></p>

	<p>Cirriculum Vitae (CV): <a href="<?php echo e(route('download', ['fileName' => $panel->cv_url])); ?>">Download</a></p>
<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/emails/registration-received.blade.php ENDPATH**/ ?>