<nav class="navbar navbar-expand-lg navbar-dark navbar-sticky-top" style = "background-color: #000">
    <div class="container" style="font-size:0.8rem">
        <a class="navbar-brand" href="<?php echo e(route('homepage')); ?>">
          <img src="<?php echo e(logo()); ?>" width="auto" height="30px" alt="">
        </a>
  
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('homepage')); ?>"> FREE TIPS</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('homepage')); ?>/blog">BLOG</a>
            </li>

          </ul>

          <?php if(auth()->check() && auth()->user()->is_standard_user()): ?>
            <span class="navbar-text">
              <?php if(auth()->user()->subscription_active()): ?>
                <span class="text-warning"><i class="fas fa-star"></i> PREMIUM MEMBERSHIP | EXPIRES <?php echo e(strtoupper(auth()->user()->subscription_expires_at->toDayDateTimeString())); ?> <i class="fas fa-star"></i></span>
              <?php else: ?>
                <span class="text-muted">FREE MEMBERSHIP</span>
              <?php endif; ?>
            </span>
          <?php endif; ?>
  
          <ul class="navbar-nav ml-auto">
           
            <?php if(auth()->check()): ?>  
                  <?php if(auth()->user()->is_standard_user()): ?>
                  
                    <?php if(auth()->user()->subscription_active()): ?>
                      <?php if(!auth()->user()->sms_subscription_active()): ?>
                        <li class="nav-item">
                          <a class="nav-link btn btn-sm btn-outline-warning" href="" data-toggle="modal" data-target="#make-sms-subscription-modal">SUBSCRIBE TO SMS</a>
                        </li>
                      <?php endif; ?>
                    <?php else: ?>
                      <li class="nav-item">
                        <a class="nav-link btn btn-sm btn-outline-warning" href="" data-toggle="modal" data-target="#make-subscription-modal">SUBSCRIBE NOW</a>
                      </li>
                    <?php endif; ?>

                    <li class="nav-item">
                      <a class="nav-link btn btn-sm btn-outline-info" href="<?php echo e(route('standard-user.history')); ?>">HISTORY</a>
                    </li>
                  
                <?php endif; ?>
            
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(auth()->user()->name); ?>

                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    <?php if(auth()->user()->is_standard_user()): ?>
                      <a class="dropdown-item" href="<?php echo e(route('standard-user.subscriptions')); ?>">Subscriptions</a>
                    <?php endif; ?>
                    <?php if(!auth()->user()->is_admin()): ?>
                      <a class="dropdown-item" href="<?php echo e(auth()->user()->is_standard_user() ? route('standard-user.settings') : route('analyst.settings')); ?>">Settings</a>
                    <?php else: ?>
                    <a class="dropdown-item" href="<?php echo e(route('admin.settings')); ?>">Settings</a>
                    <?php endif; ?>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
                  </div>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"> LOGIN</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"> REGISTER</a>
                </li> 
            <?php endif; ?>
          </ul>
          
       </div>
    </div>
  </nav><?php /**PATH C:\wamp64\www\betting\resources\views/includes/nav.blade.php ENDPATH**/ ?>