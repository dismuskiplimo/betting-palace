<nav class="navbar navbar-expand-lg navbar-sticky-top" style = "background-color: #1f338c; color:#ffffff">
    <div class="container">
        <p>Your feedback & comments matter to us: &nbsp;&nbsp; <a href="tel:+254115008170" class="btn btn-sm text-light" style="margin-top:-3px"><i class="fas fa-phone"></i> +254 115 008170</a> &nbsp;&nbsp; <a href="mailto:feedback@ncia.or.ke" class="btn btn-sm text-light" style="margin-top:-3px"><i class="fas fa-envelope"></i> feedback@ncia.or.ke</a></p>
    </div>
</nav>

<nav class="navbar navbar-expand-lg navbar-light navbar-sticky-top" style = "background-color: #ffffff">
    <div class="container" style="font-size:0.8rem">
        <a class="navbar-brand" href="https://ncia.or.ke">
          <img src="<?php echo e(logo()); ?>" width="auto" height="30px" alt="">
        </a>
  
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="https://ncia.or.ke"> HOME</a>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="mediatorDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  ARBITRATOR
                </a>
                <div class="dropdown-menu" aria-labelledby="arbitratorDropdown">
                  <a class="dropdown-item" href="<?php echo e(route('arbitrator.register')); ?>">Arbitrator Panel Status Application</a>
                  <a class="dropdown-item" href="<?php echo e(route('arbitration.request')); ?>">Request for Arbitration</a>                   
                </div>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="mediatorDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  MEDIATOR
                </a>
                <div class="dropdown-menu" aria-labelledby="mediatorDropdown">
                  <a class="dropdown-item" href="<?php echo e(route('mediator.register')); ?>">Mediator Panel Status Application</a>
                  <a class="dropdown-item" href="<?php echo e(route('mediation.request')); ?>">Request for Mediation</a>                 
                </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="trainingDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                TRAINING & ACCREDITATION
              </a>
              <div class="dropdown-menu" aria-labelledby="trainingDropdown">
                <a class="dropdown-item" href="<?php echo e(route('training.calendar')); ?>">Virtual Training Calendar</a>
                <a class="dropdown-item" href="<?php echo e(route('training.register')); ?>">Register for Training</a>
                                 
              </div>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('rooms')); ?>">ROOMS</a>
            </li>

          </ul>
  
          <ul class="navbar-nav ml-auto">
           
            <?php if(auth()->check()): ?>  
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(auth()->user()->name); ?>

                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="">Dashboard</a>
                    <a class="dropdown-item" href="">Settings</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
                  </div>
                </li>
            <?php else: ?>

                

                

            <?php endif; ?>
  
          </ul>
          
       </div>
    </div>
  </nav><?php /**PATH C:\wamp64\www\ncia\resources\views/includes/nav.blade.php ENDPATH**/ ?>