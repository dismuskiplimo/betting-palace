<style type="text/css">

	table > tr > th {
		text-align: left !important;
	}
	
</style><?php /**PATH C:\wamp64\www\ncia\resources\views/includes/email/styles.blade.php ENDPATH**/ ?>