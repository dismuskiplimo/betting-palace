<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row my-5">
            <div class="col-sm-12">
                <h4 class="text-center text-warning mb-4">TODAY'S FREE TIPS</h4>
                <table class="table table-dark table-striped">
                    <thead>
                        <tr class="text-warning">
                            <th>Time</th>
                            <th>League</th>
                            <th>GameId</th>
                            <th>Home</th>
                            <th>Away</th>
                            <th>Prediction (Tip)</th>
                            <th>Predicted Score</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if(count($bets)): ?>
                            <?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($bet->starts_at->toDayDateTimeString()); ?></td>
                                    <td><?php echo e($bet->league); ?></td>
                                    <td><?php echo e($bet->gameId); ?></td>
                                    <td><?php echo e($bet->homeName); ?></td>
                                    <td><?php echo e($bet->awayName); ?></td>
                                    <td><?php echo e($bet->prediction); ?></td>
                                    <td><?php echo e($bet->predictedHomeScore != null && $bet->predictedAwayScore != null ? $bet->predictedHomeScore . ' - ' . $bet->predictedAwayScore : '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center"><span class="text-light">Free tips will be updated shortly</span></td>
                                </tr>
                        <?php endif; ?>
                        
                    </tbody>
                </table>
            </div>
        </div>

        <div class="row my-5">
            <div class="col-sm-12 mb-5">
                <h3 class="text-center text-warning">SUSBSCRIBE NOW TO GET PREMIUM VIP TIPS </h3>
            </div>
            
            <?php $stars = 1; ?>
            <?php $__currentLoopData = $subscription_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <div class="card bg-dark border-warning">
                        <div class="card-body text-center text-light">
                            <p style="font-size: 2.5rem">
                                <?php for($i = 0; $i < $stars; $i++): ?>
                                    <i class="fas fa-star text-warning"></i>
                                <?php endfor; ?>

                                <?php $stars += 1; ?>
                            </p>
                            <h1 class="text-warning"><?php echo e($subscription_type->subscription_type); ?></h1>
                            <hr>
                            <h2><?php echo e($subscription_type->no_of_days); ?> DAYS</h2>
                            <hr>
                            <h4>KES <?php echo e(number_format($subscription_type->price)); ?>/=</h4>
                            <p class="mt-5">
                                <a href="" class="btn btn-warning btn-lg">SUBSCRIBE</a>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row my-5">
            <div class="col-12">
                <h4 class="text-center text-warning mb-4">BLOG</h4>

                <div class="row">
                    
                </div>
            </div>
        </div>
    </div>

    <?php if(auth()->check() && auth()->user()->is_standard_user()): ?>
        <?php echo $__env->make('pages.standard-user.modals.make-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('pages.standard-user.modals.make-sms-subscription', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/index.blade.php ENDPATH**/ ?>