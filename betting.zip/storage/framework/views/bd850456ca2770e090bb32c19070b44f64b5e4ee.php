<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="col-sm-3"><?php echo $__env->make('pages.admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="col-sm-9">
                <h4 class="text-warning mb-3"><?php echo e($title); ?>

                    
                </h4>

                <table class="table table-dark table-striped table-hover" style="font-size:.7rem">
                    <thead>
                        <tr class="text-warning">
                            <th>Date</th>
                            <th>Receipt</th>
                            <th>MPESA No.</th>
                            <th>Amount</th>
                            <th>Description</th>
                            <th>User</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($transaction->TransactionDate->toDayDateTimeString()); ?></td>
                                <td><?php echo e($transaction->MpesaReceiptNumber); ?></td>
                                <td><?php echo e($transaction->PhoneNumber); ?></td>
                                <td>KES <?php echo e(number_format($transaction->Amount)); ?>/=</td>
                                <td><?php echo e($transaction->description); ?></td>
                                <td><?php echo e($transaction->user->name); ?></td>
                               
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo e($transactions->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/admin/transactions.blade.php ENDPATH**/ ?>