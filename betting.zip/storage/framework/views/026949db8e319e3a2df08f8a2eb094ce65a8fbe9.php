<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="mt-5 text-center"><?php echo e($title); ?></h2>

            <div class="row text-center">
                <div class="title-separator theme-bg-blue"></div>
            </div>

            <div class="">
                <div class="">
                    <h3>Our Virtual Training Calendar</h3>
                    <p class="text-justify">
                        Pursuant to Section 5 of the NCIA Act 2013, the NCIA is mandated to provide 
                        training and accreditation programs for mediators and arbitrators and to 
                        educate the public on alternative dispute resolution (ADR) mechanisms. 
                        In execution of this mandate, NCIA is now offering accredited training 
                        programs for both Mediation and Arbitration geared towards the promotion 
                        of ADR as the preferred dispute resolution mechanism.
                    </p>
                </div>
            </div>

            <table class="table table-striped">
                <thead>
                    <tr class="theme-bg-light-blue">
                        <th class="theme-bg-light-blue">DATE</th>
                        <th class="theme-bg-light-blue">ACTIVITY</th>
                        <th class="theme-bg-light-blue">DURATION</th>
                        <th class="theme-bg-light-blue">PLACE</th>
                        <th class="theme-bg-light-blue">COST (KES)</th>
                        <th></th>
                    </tr>
                    
                </thead>
            
                <tbody>
                    <?php if($trainingCalendars->count()): ?>
                        <?php $__currentLoopData = $trainingCalendars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainingCalendar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($trainingCalendar->date); ?></td>
                                <td><?php echo e($trainingCalendar->activity); ?></td>
                                <td><?php echo e($trainingCalendar->duration); ?></td>
                                <td><?php echo e($trainingCalendar->place); ?></td>
                                <td><?php echo e(number_format($trainingCalendar->cost)); ?>/=</td>
                                <td><a href="" data-toggle="modal" data-target="#request-training-calendar-modal" data-id="<?php echo e($trainingCalendar->id); ?>" class="training-calendar-button btn btn-sm btn-ncia">Register</a></td>
                            </tr>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">Currently, there is no training</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="col-12 text-center my-5">
            <a href="https://ncia.or.ke/wp-content/uploads/2021/05/NCIA-Training-Calendar-2021-2022.pdf" class="btn btn-ncia btn-lg">Download Printable Format</a>
        </div>

        <div class="col-12">
            <p>
                * 1 Virtual Class attendance for a duration of 4 hours per month. 
                Classes begin from 9am to 1pm with scheduled breaks
            </p>

            <p>
                For registration, you may use the 
                <a href="<?php echo e(route('training.register')); ?>">online registration form</a> 
                or  call + 254 771 293 055 or email us on 
                <a href="mailto:<?php echo e(env("TRAINING_APPLICATION_EMAIL")); ?>"><?php echo e(env("TRAINING_APPLICATION_EMAIL")); ?></a>
            </p>
        </div>
    </div>
</div>

<?php echo $__env->make('modals.request-training-calendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/pages/training-calendar.blade.php ENDPATH**/ ?>