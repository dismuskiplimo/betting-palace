<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="col-sm-3"><?php echo $__env->make('pages.admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="col-sm-9">
                <h4 class="text-warning mb-3"><?php echo e($title); ?>

                    <div class="btn-group float-right" role="group" aria-label="Basic example">
                        <a href="<?php echo e(route('admin.subscriptions', ['category' => 'all'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'all' ? ' active' : ''); ?>">All</a>
                        <a href="<?php echo e(route('admin.subscriptions', ['category' => 'active'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'active' ? ' active' : ''); ?>">Active</a>
                        <a href="<?php echo e(route('admin.subscriptions', ['category' => 'expired'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'expired' ? ' active' : ''); ?>">Expired</a>
                    </div>
                </h4>

                <table class="table table-dark table-striped table-hover" style="font-size:.7rem">
                    <thead>
                        <tr class="text-warning">
                            <th>Start</th>
                            <th>End</th>
                            <th>User</th>
                            <th>Details</th>
                            <th>MPESA Number</th>
                            <th>Amount</th>
                            <th>Transaction Code</th>
                            <th>Paid</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($subscription->starts_at->toDayDateTimeString()); ?></td>
                                <td><?php echo e($subscription->ends_at->toDayDateTimeString()); ?></td>
                                <td><?php echo e($subscription->user->name); ?></td>
                                <td><?php echo e($subscription->subscription_details); ?></td>
                                <td><?php echo e($subscription->mpesa_number); ?></td>
                                <td>KES <?php echo e(number_format($subscription->mpesa_amount)); ?>/=</td>
                                <td><?php echo e($subscription->mpesa_trx_code); ?></td>
                                <td><?php echo e($subscription->completed_at->toDayDateTimeString()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo e($subscriptions->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/admin/subscriptions.blade.php ENDPATH**/ ?>