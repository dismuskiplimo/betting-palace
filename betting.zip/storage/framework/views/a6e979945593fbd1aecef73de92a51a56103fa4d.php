<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="mt-5 text-center"><?php echo e($title); ?></h2>

            <div class="row text-center">
                <div class="title-separator theme-bg-blue"></div>
            </div>

            <div>
                
                <ul class="nav nav-pills nav-fill" id="myTab" role="tablist">
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <a class="btn-ncia mr-3 nav-link<?php echo e($room->id == $first->id ? " active" : ""); ?>" id="<?php echo e(str_slug($room->room_name) . '-' . $room->id); ?>" data-toggle="tab" href="#section-<?php echo e(str_slug($room->room_name) . '-' . $room->id); ?>" role="tab" aria-controls="<?php echo e($room->room_name); ?>" aria-selected="true"><?php echo e($room->room_name); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="tab-content" id="myTabContent">
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade<?php echo e($room->id == $first->id ? " show active" : ""); ?>" id="section-<?php echo e(str_slug($room->room_name) . '-' . $room->id); ?>" role="tabpanel" aria-labelledby="<?php echo e($room->room_name); ?>-tab">
                            <div class="row mt-5">
                                
                                <div class="col-sm-7">
                                    <img class="img-fluid" src="<?php echo e(custom_asset("images/rooms/" . $room->images->first()->img_url)); ?>" alt="<?php echo e($room->room_name); ?>">
                                </div>

                                <div class="col-sm-5">
                                    <h2><?php echo e($room->room_name); ?></h2>

                                    <?php echo clean($room->description); ?>


                                    <?php if($room->available): ?>
                                        <a class="book-room-button btn btn-ncia" href="" data-toggle="modal" data-id="<?php echo e($room->id); ?>" data-max="<?php echo e($room->max_capacity); ?>" data-target="#book-room-modal">Book Room</a>
                                    <?php endif; ?>
                                </div>
                            </div>      
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('modals.book-room', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/pages/rooms.blade.php ENDPATH**/ ?>