<div class="modal fade" id="book-room-modal" role="dialog">
    <div class="modal-dialog" role ="document">
      <div class="modal-content">
        <form action="<?php echo e(route('rooms')); ?>" method="POST" class="book_room_form">
          <?php echo csrf_field(); ?>
          
          <div class="modal-header">
            <h5 class="modal-title">Book Room</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          
          <div class="modal-body">
            <div class="row">
                <div class="col-sm-12">                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Contact Name<span class="text-danger">*</span></label>
                                <input type="text" name = "contact_name" class="form-control" required="" placeholder="contact name">
                            </div>
                        </div>
                    </div>

                    <div class="row">                        
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Room<span class="text-danger">*</span></label>
                                <select name="room_id" class="form-control available-rooms" id="" required = "">
                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($room->available): ?>
                                            <option value="<?php echo e($room->id); ?>"><?php echo e($room->room_name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Duration<span class="text-danger">*</span></label>
                                <select name="duration" class="form-control available-rooms" id="" required = "">
                                    <option value="full_day" selected="">Full Day</option>
                                    <option value="half_day">Half Day</option>
                                </select>
                            </div>
                        </div>

                    </div>
                
                    <div class="row">                     
                        <div class="col-sm-6">
                            <div class = "form-group">
                                <label>From<span class="text-danger">*</span></label>
                                <input type = "text" class = "form-control start-date" readonly="readonly" name = "start_date" required = "" placeholder = "from">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class = "form-group">
                                <label>To<span class="text-danger">*</span></label>
                                <input type = "text" class = "form-control end-date" readonly="readonly" name = "end_date" required = "" placeholder = "to">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Number of Participants<span class="text-danger">*</span></label>
                                <input type="number" name="no_of_participants" value="1" min = "1" id="" placeholder="number of participants" class="no_of_participants form-control" required = "">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Name of organization\entity<span class="text-danger">*</span></label>
                                <input type="text" name = "organization" class="form-control" required="" placeholder="organization\entity">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Nature of Session<span class="text-danger">*</span></label>
                                <textarea name="nature_of_session" id="" placeholder="nature of session" class="form-control" required = ""></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Telephone No<span class="text-danger">*</span></label>
                                <input type="text" name = "telephone" class="form-control" required="" placeholder="telephone">
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Email<span class="text-danger">*</span></label>
                                <input type="email" name = "email" class="form-control" required="" placeholder="email">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-outline-success">Book Room</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\ncia\resources\views/modals/book-room.blade.php ENDPATH**/ ?>