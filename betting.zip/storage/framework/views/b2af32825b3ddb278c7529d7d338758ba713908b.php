<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-5">
            <div class="col-sm-3"><?php echo $__env->make('pages.admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="col-sm-9">
                <div class="btn-group mb-3 btn-group-justify" role="group" aria-label="">
                    <a href="<?php echo e(route('admin.users', ['category' => 'all'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'all' ? ' active' : ''); ?>">All Users</a>
                    <a href="<?php echo e(route('admin.users', ['category' => 'active'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'active' ? ' active' : ''); ?>">Subscribed to tips</a>
                    <a href="<?php echo e(route('admin.users', ['category' => 'inactive'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'inactive' ? ' active' : ''); ?>">Not Subscribed to tips</a>
                    <a href="<?php echo e(route('admin.users', ['category' => 'active-sms'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'active-sms' ? ' active' : ''); ?>">Subscribed to SMS</a>
                    <a href="<?php echo e(route('admin.users', ['category' => 'inactive-sms'])); ?>" class="btn btn-sm btn-outline-warning"<?php echo e($category == 'inactive-sms' ? ' active' : ''); ?>>Not Subscribed to SMS</a>
                    <a href="<?php echo e(route('admin.users', ['category' => 'analyst'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'analyst' ? ' active' : ''); ?>">Analysts</a>
                    <a href="<?php echo e(route('admin.users', ['category' => 'admin'])); ?>" class="btn btn-sm btn-outline-warning<?php echo e($category == 'admin' ? ' active' : ''); ?>">Admins</a>
                </div>
                
                <h4 class="text-warning mb-3"><?php echo e($title); ?>

                    <a href="" data-toggle="modal" data-target="#add-user-modal" class="btn btn-warning btn-sm float-right">Add User</a>
                </h4>

                <table class="table table-dark table-striped" style="font-size:.7rem">
                    <thead>
                        <tr class="text-warning">
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>User Type</th>
                            <th>Bet Subscription</th>
                            <th>Bet Subscription Expires</th>
                            <th>SMS Subscription</th>
                            <th>SMS Subscription Expires</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->user_type); ?></td>
                                <td><?php echo e(!is_null($user->subscription_expires_at) && $user->subscription_expires_at->gt(\Carbon\Carbon::now()) ? "PREMIUM" : "FREE"); ?></td>
                                <td><?php echo e(!is_null($user->subscription_expires_at) && $user->subscription_expires_at->gt(\Carbon\Carbon::now()) ? $user->subscription_expires_at->toDayDateTimeString() : ""); ?></td>
                                <td><?php echo e(!is_null($user->sms_subscription_expires_at) && $user->sms_subscription_expires_at->gt(\Carbon\Carbon::now()) ? "SUBSCRIBED" : ""); ?></td>
                                <td><?php echo e(!is_null($user->sms_subscription_expires_at) && $user->sms_subscription_expires_at->gt(\Carbon\Carbon::now()) ? $user->sms_subscription_expires_at->toDayDateTimeString() : ""); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>

    <?php echo $__env->make('pages.admin.modals.add-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\betting\resources\views/pages/admin/users.blade.php ENDPATH**/ ?>