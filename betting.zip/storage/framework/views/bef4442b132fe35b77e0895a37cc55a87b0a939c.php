<?php $__env->startSection('content'); ?>
	<p>Developer,</p>
	
	<h3>Action needed</h3>

	<p><?php echo e($e->getMessage()); ?></p>

	<p><?php echo clean($e); ?></p>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/emails/exception-detected.blade.php ENDPATH**/ ?>