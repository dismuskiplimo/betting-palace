<div class="modal fade" id="make-subscription-modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered text-dark" role ="document">
      <div class="modal-content">
        <form action="<?php echo e(route('payment.request.mpesa', ['type' => 'predictions'])); ?>" method="POST" class="book_room_form">
          <?php echo csrf_field(); ?>
          
          <div class="modal-header">
            <h5 class="modal-title">Subscribe to Paid Predictions</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          
          <div class="modal-body">                 
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="">Phone Number to make MPESA payment (Safaricom only). Please use the format 2547XXXXXXXX e.g 254725678921. Any other format will fail. An STK push will be sent to your phone to which you will input your MPESA PIN to authorize payment.<span class="text-danger">*</span></label>
                        <input type="number" name="phone" value="<?php echo e(auth()->user()->phone); ?>" id="" placeholder="254XXXXXXXXX" class="form-control" required = "">
                    </div>
                </div>
            </div>
        
            <div class="row">                        
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="">Subscription Type<span class="text-danger">*</span></label>
                        <select name="subscription_type_id" class="form-control available-rooms" id="" required = "">
                            <?php $__currentLoopData = \App\SubscriptionType::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriptionType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($subscriptionType->id); ?>"><?php echo e($subscriptionType->subscription_type); ?> (KES <?php echo e(number_format($subscriptionType->price)); ?>/=)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
          </div>
          
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-outline-success">Subscribe</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\betting\resources\views/pages/standard-user/modals/make-subscription.blade.php ENDPATH**/ ?>