        
    </body>
</html><?php /**PATH C:\wamp64\www\ncia\resources\views/includes/footer.blade.php ENDPATH**/ ?>