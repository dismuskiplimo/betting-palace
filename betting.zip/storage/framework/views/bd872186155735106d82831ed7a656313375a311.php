<div class="modal fade" id="request-training-calendar-modal" role="dialog">
    <div class="modal-dialog modal-lg" role ="document">
      <div class="modal-content">
        <form action="<?php echo e(route('training.register')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          
          <div class="modal-header">
            <h5 class="modal-title">Register for Course</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          
          <div class="modal-body">
            <div class="row">
              <div class="col-sm-12">
               
                <div class="row mb-3">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="">Course  <span class="text-danger">*</span></label>
                            
                            <select name = "course_title" class="form-control course_title" required="">
                                <?php $__currentLoopData = $trainingCalendars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainingCalendar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trainingCalendar->id); ?>">
                                        <?php echo e($trainingCalendar->activity); ?> |
                                        <?php echo e($trainingCalendar->date); ?> | 
                                        <?php echo e($trainingCalendar->duration); ?>

                                    </option>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>                            
                        </div>
                    </div>
                </div>

                <h4 class="mb-3">PERSONAL DETAILS</h4>

                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="title">Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="title" class="form-control" required="required" placeholder="title">
                        </div>
                    </div>
                    
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="first-name">First Name<span class="text-danger">*</span></label>
                            <input type="text" name="first_name" id="first-name" class="form-control" required="required" placeholder="first name">
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="middle-name">Middle Name</label>
                            <input type="text" name="middle_name" id="middle-name" class="form-control" placeholder="middle name">
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="last-name">Last Name<span class="text-danger">*</span></label>
                            <input type="text" name="last_name" id="last-name" class="form-control" required="required" placeholder="last name">
                        </div>
                    </div>
                </div>

                <div class="row">
                
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="telephone">Telephone </label>
                            <input type="text" name="telephone" id="telephone" class="form-control" placeholder="telephone">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="city">Gender <span class="text-danger">*</span></label>

                            <div class="radio">
                                <label for="">
                                    <input type="radio" name="gender" value="male" checked=""> Male
                                    <input type="radio" name="gender" value="female"> Female
                                </label>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="address">Address<span class="text-danger">*</span></label>
                            <input type="text" name="address" id="address" class="form-control" required="required" placeholder="address">
                        </div>
                    </div>
                </div>

                <div class="row">
                
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="postal-code">Postal Code<span class="text-danger">*</span></label>
                            <input type="text" name="postal_code" id="postal-code" class="form-control" required="required" placeholder="postal code">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="city">Town/County<span class="text-danger">*</span></label>
                            <input type="text" name="city" id="city" class="form-control" required="required" placeholder="town/county">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="mobile">Mobile<span class="text-danger">*</span></label>
                            <input type="text" name="mobile" id="mobile" class="form-control" required="required" placeholder="mobile no">
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="email">Email<span class="text-danger">*</span></label>
                            <input type="email" name="email" id="email" class="form-control" required="required" placeholder="email">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="firm">Employer/Firm/Organization</label>
                            <input type="text" name="firm" id="firm" class="form-control" placeholder="employer/firm/organization">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="bank_transfer_date">Bank Transfer Deposit/Transfer Date <span class="text-danger">*</span></label>
                            <input type="text" name="bank_transfer_date" id="bank_transfer_date" class="form-control" required="required" placeholder="Bank Transfer Deposit/Transfer Date">
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="payment_method">Payment Method<span class="text-danger">*</span></label>
                            <div class="radio">
                                <label for="">
                                    <input type="radio" name="payment_method" value="Cheque" checked=""> Cheque 
                                    <input type="radio" name="payment_method" value="Bank Draft"> Bank Draft
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label for="receipt_no">Receipt no</label>
                            <input type="text" name="receipt_no" id="receipt_no" class="form-control" placeholder="receipt no">
                        </div>
                    </div>
                </div>

                <p>
                    <strong>N/B: </strong>Any costs arising out of unpaid or uncleared cheque will be paid by the applicant
                </p>

                <p><strong>Bank Details</strong></p>

                <p>
                    <strong>Account Name: </strong>Nairobi Centre for International Arbitration <br>
                    <strong>Bank: </strong>Kenya Commercial Bank, KICC Branch <br>
                    <strong>Swift Code: </strong>KCBLKENX <br>
                    <strong>Account No. (KES): </strong>1180828607 <br>
                    <strong>Account No. (USD): </strong>1181122961
                </p>

                <div class="checkbox">
                    <label for=""><input type="checkbox" name="accepted" required=""> I accept that the information provided above is truthful and NCIA has the mandate to approve or reject my application</label>
                </div>

                <p> <span class="text-danger">*</span> required</p>

              </div>
            </div>
          </div>
          
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-outline-success">Register</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\ncia\resources\views/modals/request-training-calendar.blade.php ENDPATH**/ ?>