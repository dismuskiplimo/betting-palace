<div class="modal fade" id="create-grouping-modal" role="dialog">
    <div class="modal-dialog modal-lg modal-dialog-centered text-dark" role ="document">
      <div class="modal-content">
        <form action="<?php echo e(route('analyst.betslip.add')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          
          <div class="modal-header">
            <h5 class="modal-title">Create Grouping</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          
          <div class="modal-body">
            <div class="row">
              <div class="col-12">
                <p>Select games to group</p>
                <?php $__currentLoopData = $active_bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                          
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="<?php echo e($bet->id); ?>" name="bets[]" id="defaultCheck<?php echo e($bet->id); ?>">
                      <label class="form-check-label" for="defaultCheck<?php echo e($bet->id); ?>">
                        <?php echo e($bet->homeName); ?> - <?php echo e($bet->awayName); ?> - (<?php echo e($bet->league); ?>) <?php echo e($bet->gameId); ?> -  <?php echo e($bet->starts_at->toDayDateTimeString()); ?> - (Tip: <?php echo e($bet->prediction); ?>) <?php echo e(!is_null($bet->predictedHomeScore) && !is_null($bet->predictedAwayScore) ? ' (CS: ' . $bet->predictedHomeScore . ' - ' . $bet->predictedAwayScore . ')' : ''); ?>

                      </label>
                    </div>

                    <hr>
               
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
          
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-outline-success">Add</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\betting\resources\views/pages/analyst/modals/create-grouping.blade.php ENDPATH**/ ?>