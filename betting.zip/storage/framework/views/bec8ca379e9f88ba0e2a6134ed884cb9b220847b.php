<?php echo $__env->make('includes.email.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="container">
		<p class="text-center"> <img src="<?php echo e($message->embed(logo_absolute())); ?>" alt="<?php echo e(config('app.name')); ?> Logo" style="max-width: 100%;height: auto"> </p> <br>
		
		<hr> <br>

		<?php echo $__env->yieldContent('content'); ?>		
	</div>

<?php echo $__env->make('includes.email.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/layouts/email.blade.php ENDPATH**/ ?>