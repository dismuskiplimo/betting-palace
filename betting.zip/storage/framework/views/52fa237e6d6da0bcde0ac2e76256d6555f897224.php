<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-12">
            
            <h2 class="mt-5 text-center"><?php echo e($title); ?></h2>

            <div class="row text-center">
                <div class="title-separator theme-bg-blue"></div>
            </div>

            <form action="<?php echo e(route('panel.register')); ?>" id="registration-form" method="POST"
                enctype="multipart/form-data">
                
                <div class="row steps mb-5">
                    <span class="registration-step step-1 active">
                        1
                    </span>

                    <span class="registration-step step-2">
                        2
                    </span>

                    <span class="registration-step step-3">
                        3
                    </span>

                    <span class="registration-step step-4">
                        4
                    </span>

                    <span class="registration-step step-5">
                        5
                    </span>
                </div>

                <ul class="nav nav-tabs" id="myTab" role="tablist" style="display: none;">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="step-1-tab" data-toggle="tab" href="#step-1" role="tab"
                            aria-controls="step-1" aria-selected="true">Step 1</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="step-2-tab" data-toggle="tab" href="#step-2" role="tab"
                            aria-controls="step-2" aria-selected="false">Step 2</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="step-3-tab" data-toggle="tab" href="#step-3" role="tab"
                            aria-controls="step-3" aria-selected="false">Step 3</a>
                    </li>
            
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="step-4-tab" data-toggle="tab" href="#step-4" role="tab"
                            aria-controls="step-4" aria-selected="false">Step 4</a>
                    </li>
            
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="step-5-tab" data-toggle="tab" href="#step-5" role="tab"
                            aria-controls="step-5" aria-selected="false">Step 5</a>
                    </li>
                </ul>
            
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="step-1" role="tabpanel" aria-labelledby="step-1">
                        <div class="card my-5">
                            <div class="card-body">       
                                <div class="row mb-5 text-center">
                                    <div class="col-12">
                                        <h2>PARTICULARS OF APPLICANT</h2>
                                    </div>
                                </div>
                                
                                <div class="row mb-5">
                                    <div class="col-sm-6 text-center">
                                        
                                        <img src="<?php echo e(custom_asset("images/default-user.png")); ?>" alt="" style = "max-height: 200px; width: auto;" id = "photo-preview">
            
                                        <div class="form-group">
                                            <input type="file" accept="image/*" name="photo" id="photo-file" style="display: none;">
                                        </div>
            
                                        <button type = "button" class="btn btn-info" style="background-color: #005DAE;" id = "photo-button">Select Photo</button>
            
                                    </div>
                                    <div class="col-sm-6">
                                        
                                        <div class="form-group" style="display: none;">
                                            <label for="panel-type">Panel Type<span class="text-danger">*</span></label>
                                            <select name="panel_type" id="panel-type" class="form-control" required="required">
                                                <option value="arbitrator" selected="selected">Arbitrator</option>
                                                <option value="mediator">Mediator</option>
                                            </select>
                                        </div>
            
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="first-name">First Name<span class="text-danger">*</span></label>
                                                    <input type="text" name="first_name" id="first-name" class="form-control" required="required" placeholder="first name">
                                                </div>
                                            </div>
            
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="middle-name">Middle Name</label>
                                                    <input type="text" name="middle_name" id="middle-name" class="form-control" placeholder="middle name">
                                                </div>
                                            </div>
            
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="last-name">Last Name<span class="text-danger">*</span></label>
                                                    <input type="text" name="last_name" id="last-name" class="form-control" required="required" placeholder="last name">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                   
                                
                                <hr class="my-4">
            
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="panel-category">Category applying for <span class="text-danger">*</span></label>
                                            <select name="panel_category" id="panel-category" class="form-control" required="required">
                                                <option value="domestic" selected="selected">Domestic Arbitration</option>
                                                <option value="international">International Arbitration</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="nationality">Nationality<span class="text-danger">*</span></label>
                                            <select name="nationality" id="nationality" class="form-control" required="required">
                                                <option value="Afghanistan">Afghanistan</option>
                                                <option value="Åland Islands">Åland Islands</option>
                                                <option value="Albania">Albania</option>
                                                <option value="Algeria">Algeria</option>
                                                <option value="American Samoa">American Samoa</option>
                                                <option value="Andorra">Andorra</option>
                                                <option value="Angola">Angola</option>
                                                <option value="Anguilla">Anguilla</option>
                                                <option value="Antarctica">Antarctica</option>
                                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                                <option value="Argentina">Argentina</option>
                                                <option value="Armenia">Armenia</option>
                                                <option value="Aruba">Aruba</option>
                                                <option value="Australia">Australia</option>
                                                <option value="Austria">Austria</option>
                                                <option value="Azerbaijan">Azerbaijan</option>
                                                <option value="Bahamas">Bahamas</option>
                                                <option value="Bahrain">Bahrain</option>
                                                <option value="Bangladesh">Bangladesh</option>
                                                <option value="Barbados">Barbados</option>
                                                <option value="Belarus">Belarus</option>
                                                <option value="Belgium">Belgium</option>
                                                <option value="Belize">Belize</option>
                                                <option value="Benin">Benin</option>
                                                <option value="Bermuda">Bermuda</option>
                                                <option value="Bhutan">Bhutan</option>
                                                <option value="Bolivia">Bolivia</option>
                                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                                <option value="Botswana">Botswana</option>
                                                <option value="Bouvet Island">Bouvet Island</option>
                                                <option value="Brazil">Brazil</option>
                                                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                                <option value="Brunei Darussalam">Brunei Darussalam</option>
                                                <option value="Bulgaria">Bulgaria</option>
                                                <option value="Burkina Faso">Burkina Faso</option>
                                                <option value="Burundi">Burundi</option>
                                                <option value="Cambodia">Cambodia</option>
                                                <option value="Cameroon">Cameroon</option>
                                                <option value="Canada">Canada</option>
                                                <option value="Cape Verde">Cape Verde</option>
                                                <option value="Cayman Islands">Cayman Islands</option>
                                                <option value="Central African Republic">Central African Republic</option>
                                                <option value="Chad">Chad</option>
                                                <option value="Chile">Chile</option>
                                                <option value="China">China</option>
                                                <option value="Christmas Island">Christmas Island</option>
                                                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                                <option value="Colombia">Colombia</option>
                                                <option value="Comoros">Comoros</option>
                                                <option value="Congo">Congo</option>
                                                <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                                                <option value="Cook Islands">Cook Islands</option>
                                                <option value="Costa Rica">Costa Rica</option>
                                                <option value="Cote D'ivoire">Cote D'ivoire</option>
                                                <option value="Croatia">Croatia</option>
                                                <option value="Cuba">Cuba</option>
                                                <option value="Cyprus">Cyprus</option>
                                                <option value="Czech Republic">Czech Republic</option>
                                                <option value="Denmark">Denmark</option>
                                                <option value="Djibouti">Djibouti</option>
                                                <option value="Dominica">Dominica</option>
                                                <option value="Dominican Republic">Dominican Republic</option>
                                                <option value="Ecuador">Ecuador</option>
                                                <option value="Egypt">Egypt</option>
                                                <option value="El Salvador">El Salvador</option>
                                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                <option value="Eritrea">Eritrea</option>
                                                <option value="Estonia">Estonia</option>
                                                <option value="Ethiopia">Ethiopia</option>
                                                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                                <option value="Faroe Islands">Faroe Islands</option>
                                                <option value="Fiji">Fiji</option>
                                                <option value="Finland">Finland</option>
                                                <option value="France">France</option>
                                                <option value="French Guiana">French Guiana</option>
                                                <option value="French Polynesia">French Polynesia</option>
                                                <option value="French Southern Territories">French Southern Territories</option>
                                                <option value="Gabon">Gabon</option>
                                                <option value="Gambia">Gambia</option>
                                                <option value="Georgia">Georgia</option>
                                                <option value="Germany">Germany</option>
                                                <option value="Ghana">Ghana</option>
                                                <option value="Gibraltar">Gibraltar</option>
                                                <option value="Greece">Greece</option>
                                                <option value="Greenland">Greenland</option>
                                                <option value="Grenada">Grenada</option>
                                                <option value="Guadeloupe">Guadeloupe</option>
                                                <option value="Guam">Guam</option>
                                                <option value="Guatemala">Guatemala</option>
                                                <option value="Guernsey">Guernsey</option>
                                                <option value="Guinea">Guinea</option>
                                                <option value="Guinea-bissau">Guinea-bissau</option>
                                                <option value="Guyana">Guyana</option>
                                                <option value="Haiti">Haiti</option>
                                                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                                <option value="Honduras">Honduras</option>
                                                <option value="Hong Kong">Hong Kong</option>
                                                <option value="Hungary">Hungary</option>
                                                <option value="Iceland">Iceland</option>
                                                <option value="India">India</option>
                                                <option value="Indonesia">Indonesia</option>
                                                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                                <option value="Iraq">Iraq</option>
                                                <option value="Ireland">Ireland</option>
                                                <option value="Isle of Man">Isle of Man</option>
                                                <option value="Israel">Israel</option>
                                                <option value="Italy">Italy</option>
                                                <option value="Jamaica">Jamaica</option>
                                                <option value="Japan">Japan</option>
                                                <option value="Jersey">Jersey</option>
                                                <option value="Jordan">Jordan</option>
                                                <option value="Kazakhstan">Kazakhstan</option>
                                                <option value="Kenya" selected="selected">Kenya</option>
                                                <option value="Kiribati">Kiribati</option>
                                                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                                <option value="Korea, Republic of">Korea, Republic of</option>
                                                <option value="Kuwait">Kuwait</option>
                                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                                <option value="Latvia">Latvia</option>
                                                <option value="Lebanon">Lebanon</option>
                                                <option value="Lesotho">Lesotho</option>
                                                <option value="Liberia">Liberia</option>
                                                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                                <option value="Liechtenstein">Liechtenstein</option>
                                                <option value="Lithuania">Lithuania</option>
                                                <option value="Luxembourg">Luxembourg</option>
                                                <option value="Macao">Macao</option>
                                                <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                                <option value="Madagascar">Madagascar</option>
                                                <option value="Malawi">Malawi</option>
                                                <option value="Malaysia">Malaysia</option>
                                                <option value="Maldives">Maldives</option>
                                                <option value="Mali">Mali</option>
                                                <option value="Malta">Malta</option>
                                                <option value="Marshall Islands">Marshall Islands</option>
                                                <option value="Martinique">Martinique</option>
                                                <option value="Mauritania">Mauritania</option>
                                                <option value="Mauritius">Mauritius</option>
                                                <option value="Mayotte">Mayotte</option>
                                                <option value="Mexico">Mexico</option>
                                                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                                <option value="Moldova, Republic of">Moldova, Republic of</option>
                                                <option value="Monaco">Monaco</option>
                                                <option value="Mongolia">Mongolia</option>
                                                <option value="Montenegro">Montenegro</option>
                                                <option value="Montserrat">Montserrat</option>
                                                <option value="Morocco">Morocco</option>
                                                <option value="Mozambique">Mozambique</option>
                                                <option value="Myanmar">Myanmar</option>
                                                <option value="Namibia">Namibia</option>
                                                <option value="Nauru">Nauru</option>
                                                <option value="Nepal">Nepal</option>
                                                <option value="Netherlands">Netherlands</option>
                                                <option value="Netherlands Antilles">Netherlands Antilles</option>
                                                <option value="New Caledonia">New Caledonia</option>
                                                <option value="New Zealand">New Zealand</option>
                                                <option value="Nicaragua">Nicaragua</option>
                                                <option value="Niger">Niger</option>
                                                <option value="Nigeria">Nigeria</option>
                                                <option value="Niue">Niue</option>
                                                <option value="Norfolk Island">Norfolk Island</option>
                                                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                                <option value="Norway">Norway</option>
                                                <option value="Oman">Oman</option>
                                                <option value="Pakistan">Pakistan</option>
                                                <option value="Palau">Palau</option>
                                                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                                <option value="Panama">Panama</option>
                                                <option value="Papua New Guinea">Papua New Guinea</option>
                                                <option value="Paraguay">Paraguay</option>
                                                <option value="Peru">Peru</option>
                                                <option value="Philippines">Philippines</option>
                                                <option value="Pitcairn">Pitcairn</option>
                                                <option value="Poland">Poland</option>
                                                <option value="Portugal">Portugal</option>
                                                <option value="Puerto Rico">Puerto Rico</option>
                                                <option value="Qatar">Qatar</option>
                                                <option value="Reunion">Reunion</option>
                                                <option value="Romania">Romania</option>
                                                <option value="Russian Federation">Russian Federation</option>
                                                <option value="Rwanda">Rwanda</option>
                                                <option value="Saint Helena">Saint Helena</option>
                                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                <option value="Saint Lucia">Saint Lucia</option>
                                                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                                <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                                                <option value="Samoa">Samoa</option>
                                                <option value="San Marino">San Marino</option>
                                                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                                <option value="Saudi Arabia">Saudi Arabia</option>
                                                <option value="Senegal">Senegal</option>
                                                <option value="Serbia">Serbia</option>
                                                <option value="Seychelles">Seychelles</option>
                                                <option value="Sierra Leone">Sierra Leone</option>
                                                <option value="Singapore">Singapore</option>
                                                <option value="Slovakia">Slovakia</option>
                                                <option value="Slovenia">Slovenia</option>
                                                <option value="Solomon Islands">Solomon Islands</option>
                                                <option value="Somalia">Somalia</option>
                                                <option value="South Africa">South Africa</option>
                                                <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                                                <option value="Spain">Spain</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                                <option value="Sudan">Sudan</option>
                                                <option value="Suriname">Suriname</option>
                                                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                                <option value="Swaziland">Swaziland</option>
                                                <option value="Sweden">Sweden</option>
                                                <option value="Switzerland">Switzerland</option>
                                                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                                <option value="Tajikistan">Tajikistan</option>
                                                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                                <option value="Thailand">Thailand</option>
                                                <option value="Timor-leste">Timor-leste</option>
                                                <option value="Togo">Togo</option>
                                                <option value="Tokelau">Tokelau</option>
                                                <option value="Tonga">Tonga</option>
                                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                                <option value="Tunisia">Tunisia</option>
                                                <option value="Turkey">Turkey</option>
                                                <option value="Turkmenistan">Turkmenistan</option>
                                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                <option value="Tuvalu">Tuvalu</option>
                                                <option value="Uganda">Uganda</option>
                                                <option value="Ukraine">Ukraine</option>
                                                <option value="United Arab Emirates">United Arab Emirates</option>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="United States">United States</option>
                                                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                                <option value="Uruguay">Uruguay</option>
                                                <option value="Uzbekistan">Uzbekistan</option>
                                                <option value="Vanuatu">Vanuatu</option>
                                                <option value="Venezuela">Venezuela</option>
                                                <option value="Viet Nam">Viet Nam</option>
                                                <option value="Virgin Islands, British">Virgin Islands, British</option>
                                                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                                <option value="Wallis and Futuna">Wallis and Futuna</option>
                                                <option value="Western Sahara">Western Sahara</option>
                                                <option value="Yemen">Yemen</option>
                                                <option value="Zambia">Zambia</option>
                                                <option value="Zimbabwe">Zimbabwe</option>
                                            </select>
                                        </div>
                                    </div>
            
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="id-no">ID/Pssport Number<span class="text-danger">*</span></label>
                                            <input type="text" name="id_no" id="id-no" class="form-control" required="required" placeholder="ID/Passport no.">
                                        </div>
                                    </div>
                                </div>
            
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="other-nationality">Other Nationality (if applicable)</label>
                                            <select name="other_nationality" id="other-nationality" class="form-control">
                                                <option value="" selected="selected">N/A</option>
                                                <option value="Afghanistan">Afghanistan</option>
                                                <option value="Åland Islands">Åland Islands</option>
                                                <option value="Albania">Albania</option>
                                                <option value="Algeria">Algeria</option>
                                                <option value="American Samoa">American Samoa</option>
                                                <option value="Andorra">Andorra</option>
                                                <option value="Angola">Angola</option>
                                                <option value="Anguilla">Anguilla</option>
                                                <option value="Antarctica">Antarctica</option>
                                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                                <option value="Argentina">Argentina</option>
                                                <option value="Armenia">Armenia</option>
                                                <option value="Aruba">Aruba</option>
                                                <option value="Australia">Australia</option>
                                                <option value="Austria">Austria</option>
                                                <option value="Azerbaijan">Azerbaijan</option>
                                                <option value="Bahamas">Bahamas</option>
                                                <option value="Bahrain">Bahrain</option>
                                                <option value="Bangladesh">Bangladesh</option>
                                                <option value="Barbados">Barbados</option>
                                                <option value="Belarus">Belarus</option>
                                                <option value="Belgium">Belgium</option>
                                                <option value="Belize">Belize</option>
                                                <option value="Benin">Benin</option>
                                                <option value="Bermuda">Bermuda</option>
                                                <option value="Bhutan">Bhutan</option>
                                                <option value="Bolivia">Bolivia</option>
                                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                                <option value="Botswana">Botswana</option>
                                                <option value="Bouvet Island">Bouvet Island</option>
                                                <option value="Brazil">Brazil</option>
                                                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                                <option value="Brunei Darussalam">Brunei Darussalam</option>
                                                <option value="Bulgaria">Bulgaria</option>
                                                <option value="Burkina Faso">Burkina Faso</option>
                                                <option value="Burundi">Burundi</option>
                                                <option value="Cambodia">Cambodia</option>
                                                <option value="Cameroon">Cameroon</option>
                                                <option value="Canada">Canada</option>
                                                <option value="Cape Verde">Cape Verde</option>
                                                <option value="Cayman Islands">Cayman Islands</option>
                                                <option value="Central African Republic">Central African Republic</option>
                                                <option value="Chad">Chad</option>
                                                <option value="Chile">Chile</option>
                                                <option value="China">China</option>
                                                <option value="Christmas Island">Christmas Island</option>
                                                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                                <option value="Colombia">Colombia</option>
                                                <option value="Comoros">Comoros</option>
                                                <option value="Congo">Congo</option>
                                                <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                                                <option value="Cook Islands">Cook Islands</option>
                                                <option value="Costa Rica">Costa Rica</option>
                                                <option value="Cote D'ivoire">Cote D'ivoire</option>
                                                <option value="Croatia">Croatia</option>
                                                <option value="Cuba">Cuba</option>
                                                <option value="Cyprus">Cyprus</option>
                                                <option value="Czech Republic">Czech Republic</option>
                                                <option value="Denmark">Denmark</option>
                                                <option value="Djibouti">Djibouti</option>
                                                <option value="Dominica">Dominica</option>
                                                <option value="Dominican Republic">Dominican Republic</option>
                                                <option value="Ecuador">Ecuador</option>
                                                <option value="Egypt">Egypt</option>
                                                <option value="El Salvador">El Salvador</option>
                                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                <option value="Eritrea">Eritrea</option>
                                                <option value="Estonia">Estonia</option>
                                                <option value="Ethiopia">Ethiopia</option>
                                                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                                <option value="Faroe Islands">Faroe Islands</option>
                                                <option value="Fiji">Fiji</option>
                                                <option value="Finland">Finland</option>
                                                <option value="France">France</option>
                                                <option value="French Guiana">French Guiana</option>
                                                <option value="French Polynesia">French Polynesia</option>
                                                <option value="French Southern Territories">French Southern Territories</option>
                                                <option value="Gabon">Gabon</option>
                                                <option value="Gambia">Gambia</option>
                                                <option value="Georgia">Georgia</option>
                                                <option value="Germany">Germany</option>
                                                <option value="Ghana">Ghana</option>
                                                <option value="Gibraltar">Gibraltar</option>
                                                <option value="Greece">Greece</option>
                                                <option value="Greenland">Greenland</option>
                                                <option value="Grenada">Grenada</option>
                                                <option value="Guadeloupe">Guadeloupe</option>
                                                <option value="Guam">Guam</option>
                                                <option value="Guatemala">Guatemala</option>
                                                <option value="Guernsey">Guernsey</option>
                                                <option value="Guinea">Guinea</option>
                                                <option value="Guinea-bissau">Guinea-bissau</option>
                                                <option value="Guyana">Guyana</option>
                                                <option value="Haiti">Haiti</option>
                                                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                                <option value="Honduras">Honduras</option>
                                                <option value="Hong Kong">Hong Kong</option>
                                                <option value="Hungary">Hungary</option>
                                                <option value="Iceland">Iceland</option>
                                                <option value="India">India</option>
                                                <option value="Indonesia">Indonesia</option>
                                                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                                <option value="Iraq">Iraq</option>
                                                <option value="Ireland">Ireland</option>
                                                <option value="Isle of Man">Isle of Man</option>
                                                <option value="Israel">Israel</option>
                                                <option value="Italy">Italy</option>
                                                <option value="Jamaica">Jamaica</option>
                                                <option value="Japan">Japan</option>
                                                <option value="Jersey">Jersey</option>
                                                <option value="Jordan">Jordan</option>
                                                <option value="Kazakhstan">Kazakhstan</option>
                                                <option value="Kenya">Kenya</option>
                                                <option value="Kiribati">Kiribati</option>
                                                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                                <option value="Korea, Republic of">Korea, Republic of</option>
                                                <option value="Kuwait">Kuwait</option>
                                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                                <option value="Latvia">Latvia</option>
                                                <option value="Lebanon">Lebanon</option>
                                                <option value="Lesotho">Lesotho</option>
                                                <option value="Liberia">Liberia</option>
                                                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                                <option value="Liechtenstein">Liechtenstein</option>
                                                <option value="Lithuania">Lithuania</option>
                                                <option value="Luxembourg">Luxembourg</option>
                                                <option value="Macao">Macao</option>
                                                <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                                <option value="Madagascar">Madagascar</option>
                                                <option value="Malawi">Malawi</option>
                                                <option value="Malaysia">Malaysia</option>
                                                <option value="Maldives">Maldives</option>
                                                <option value="Mali">Mali</option>
                                                <option value="Malta">Malta</option>
                                                <option value="Marshall Islands">Marshall Islands</option>
                                                <option value="Martinique">Martinique</option>
                                                <option value="Mauritania">Mauritania</option>
                                                <option value="Mauritius">Mauritius</option>
                                                <option value="Mayotte">Mayotte</option>
                                                <option value="Mexico">Mexico</option>
                                                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                                <option value="Moldova, Republic of">Moldova, Republic of</option>
                                                <option value="Monaco">Monaco</option>
                                                <option value="Mongolia">Mongolia</option>
                                                <option value="Montenegro">Montenegro</option>
                                                <option value="Montserrat">Montserrat</option>
                                                <option value="Morocco">Morocco</option>
                                                <option value="Mozambique">Mozambique</option>
                                                <option value="Myanmar">Myanmar</option>
                                                <option value="Namibia">Namibia</option>
                                                <option value="Nauru">Nauru</option>
                                                <option value="Nepal">Nepal</option>
                                                <option value="Netherlands">Netherlands</option>
                                                <option value="Netherlands Antilles">Netherlands Antilles</option>
                                                <option value="New Caledonia">New Caledonia</option>
                                                <option value="New Zealand">New Zealand</option>
                                                <option value="Nicaragua">Nicaragua</option>
                                                <option value="Niger">Niger</option>
                                                <option value="Nigeria">Nigeria</option>
                                                <option value="Niue">Niue</option>
                                                <option value="Norfolk Island">Norfolk Island</option>
                                                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                                <option value="Norway">Norway</option>
                                                <option value="Oman">Oman</option>
                                                <option value="Pakistan">Pakistan</option>
                                                <option value="Palau">Palau</option>
                                                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                                <option value="Panama">Panama</option>
                                                <option value="Papua New Guinea">Papua New Guinea</option>
                                                <option value="Paraguay">Paraguay</option>
                                                <option value="Peru">Peru</option>
                                                <option value="Philippines">Philippines</option>
                                                <option value="Pitcairn">Pitcairn</option>
                                                <option value="Poland">Poland</option>
                                                <option value="Portugal">Portugal</option>
                                                <option value="Puerto Rico">Puerto Rico</option>
                                                <option value="Qatar">Qatar</option>
                                                <option value="Reunion">Reunion</option>
                                                <option value="Romania">Romania</option>
                                                <option value="Russian Federation">Russian Federation</option>
                                                <option value="Rwanda">Rwanda</option>
                                                <option value="Saint Helena">Saint Helena</option>
                                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                <option value="Saint Lucia">Saint Lucia</option>
                                                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                                <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                                                <option value="Samoa">Samoa</option>
                                                <option value="San Marino">San Marino</option>
                                                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                                <option value="Saudi Arabia">Saudi Arabia</option>
                                                <option value="Senegal">Senegal</option>
                                                <option value="Serbia">Serbia</option>
                                                <option value="Seychelles">Seychelles</option>
                                                <option value="Sierra Leone">Sierra Leone</option>
                                                <option value="Singapore">Singapore</option>
                                                <option value="Slovakia">Slovakia</option>
                                                <option value="Slovenia">Slovenia</option>
                                                <option value="Solomon Islands">Solomon Islands</option>
                                                <option value="Somalia">Somalia</option>
                                                <option value="South Africa">South Africa</option>
                                                <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                                                <option value="Spain">Spain</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                                <option value="Sudan">Sudan</option>
                                                <option value="Suriname">Suriname</option>
                                                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                                <option value="Swaziland">Swaziland</option>
                                                <option value="Sweden">Sweden</option>
                                                <option value="Switzerland">Switzerland</option>
                                                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                                <option value="Tajikistan">Tajikistan</option>
                                                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                                <option value="Thailand">Thailand</option>
                                                <option value="Timor-leste">Timor-leste</option>
                                                <option value="Togo">Togo</option>
                                                <option value="Tokelau">Tokelau</option>
                                                <option value="Tonga">Tonga</option>
                                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                                <option value="Tunisia">Tunisia</option>
                                                <option value="Turkey">Turkey</option>
                                                <option value="Turkmenistan">Turkmenistan</option>
                                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                <option value="Tuvalu">Tuvalu</option>
                                                <option value="Uganda">Uganda</option>
                                                <option value="Ukraine">Ukraine</option>
                                                <option value="United Arab Emirates">United Arab Emirates</option>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="United States">United States</option>
                                                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                                <option value="Uruguay">Uruguay</option>
                                                <option value="Uzbekistan">Uzbekistan</option>
                                                <option value="Vanuatu">Vanuatu</option>
                                                <option value="Venezuela">Venezuela</option>
                                                <option value="Viet Nam">Viet Nam</option>
                                                <option value="Virgin Islands, British">Virgin Islands, British</option>
                                                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                                <option value="Wallis and Futuna">Wallis and Futuna</option>
                                                <option value="Western Sahara">Western Sahara</option>
                                                <option value="Yemen">Yemen</option>
                                                <option value="Zambia">Zambia</option>
                                                <option value="Zimbabwe">Zimbabwe</option>
                                            </select>
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="other-id-no">Other ID/Pssport Number</label>
                                            <input type="text" name="other_id_no" id="other-id-no" class="form-control" placeholder="ID/Passport no.">
                                        </div>
                                    </div>
                                </div>
            
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="firm">Name of Firm (if applicable)</label>
                                            <input type="text" name="firm" id="firm" class="form-control" placeholder="name of firm">
                                        </div>
                                    </div>
                                </div>
            
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="mailing-address">Mailing/Physical Address</label>
                                            <input type="text" name="mailing_address" id="mailing-address" class="form-control" placeholder="address">
                                        </div>
                                    </div>
                                </div>
            
                                
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="mailing-country">Country<span class="text-danger">*</span></label>
                                            <select name="mailing_country" id="mailing-country" class="form-control" required="required">
                                                <option value="Afghanistan">Afghanistan</option>
                                                <option value="Åland Islands">Åland Islands</option>
                                                <option value="Albania">Albania</option>
                                                <option value="Algeria">Algeria</option>
                                                <option value="American Samoa">American Samoa</option>
                                                <option value="Andorra">Andorra</option>
                                                <option value="Angola">Angola</option>
                                                <option value="Anguilla">Anguilla</option>
                                                <option value="Antarctica">Antarctica</option>
                                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                                <option value="Argentina">Argentina</option>
                                                <option value="Armenia">Armenia</option>
                                                <option value="Aruba">Aruba</option>
                                                <option value="Australia">Australia</option>
                                                <option value="Austria">Austria</option>
                                                <option value="Azerbaijan">Azerbaijan</option>
                                                <option value="Bahamas">Bahamas</option>
                                                <option value="Bahrain">Bahrain</option>
                                                <option value="Bangladesh">Bangladesh</option>
                                                <option value="Barbados">Barbados</option>
                                                <option value="Belarus">Belarus</option>
                                                <option value="Belgium">Belgium</option>
                                                <option value="Belize">Belize</option>
                                                <option value="Benin">Benin</option>
                                                <option value="Bermuda">Bermuda</option>
                                                <option value="Bhutan">Bhutan</option>
                                                <option value="Bolivia">Bolivia</option>
                                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                                <option value="Botswana">Botswana</option>
                                                <option value="Bouvet Island">Bouvet Island</option>
                                                <option value="Brazil">Brazil</option>
                                                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                                <option value="Brunei Darussalam">Brunei Darussalam</option>
                                                <option value="Bulgaria">Bulgaria</option>
                                                <option value="Burkina Faso">Burkina Faso</option>
                                                <option value="Burundi">Burundi</option>
                                                <option value="Cambodia">Cambodia</option>
                                                <option value="Cameroon">Cameroon</option>
                                                <option value="Canada">Canada</option>
                                                <option value="Cape Verde">Cape Verde</option>
                                                <option value="Cayman Islands">Cayman Islands</option>
                                                <option value="Central African Republic">Central African Republic</option>
                                                <option value="Chad">Chad</option>
                                                <option value="Chile">Chile</option>
                                                <option value="China">China</option>
                                                <option value="Christmas Island">Christmas Island</option>
                                                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                                <option value="Colombia">Colombia</option>
                                                <option value="Comoros">Comoros</option>
                                                <option value="Congo">Congo</option>
                                                <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                                                <option value="Cook Islands">Cook Islands</option>
                                                <option value="Costa Rica">Costa Rica</option>
                                                <option value="Cote D'ivoire">Cote D'ivoire</option>
                                                <option value="Croatia">Croatia</option>
                                                <option value="Cuba">Cuba</option>
                                                <option value="Cyprus">Cyprus</option>
                                                <option value="Czech Republic">Czech Republic</option>
                                                <option value="Denmark">Denmark</option>
                                                <option value="Djibouti">Djibouti</option>
                                                <option value="Dominica">Dominica</option>
                                                <option value="Dominican Republic">Dominican Republic</option>
                                                <option value="Ecuador">Ecuador</option>
                                                <option value="Egypt">Egypt</option>
                                                <option value="El Salvador">El Salvador</option>
                                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                <option value="Eritrea">Eritrea</option>
                                                <option value="Estonia">Estonia</option>
                                                <option value="Ethiopia">Ethiopia</option>
                                                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                                <option value="Faroe Islands">Faroe Islands</option>
                                                <option value="Fiji">Fiji</option>
                                                <option value="Finland">Finland</option>
                                                <option value="France">France</option>
                                                <option value="French Guiana">French Guiana</option>
                                                <option value="French Polynesia">French Polynesia</option>
                                                <option value="French Southern Territories">French Southern Territories</option>
                                                <option value="Gabon">Gabon</option>
                                                <option value="Gambia">Gambia</option>
                                                <option value="Georgia">Georgia</option>
                                                <option value="Germany">Germany</option>
                                                <option value="Ghana">Ghana</option>
                                                <option value="Gibraltar">Gibraltar</option>
                                                <option value="Greece">Greece</option>
                                                <option value="Greenland">Greenland</option>
                                                <option value="Grenada">Grenada</option>
                                                <option value="Guadeloupe">Guadeloupe</option>
                                                <option value="Guam">Guam</option>
                                                <option value="Guatemala">Guatemala</option>
                                                <option value="Guernsey">Guernsey</option>
                                                <option value="Guinea">Guinea</option>
                                                <option value="Guinea-bissau">Guinea-bissau</option>
                                                <option value="Guyana">Guyana</option>
                                                <option value="Haiti">Haiti</option>
                                                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                                <option value="Honduras">Honduras</option>
                                                <option value="Hong Kong">Hong Kong</option>
                                                <option value="Hungary">Hungary</option>
                                                <option value="Iceland">Iceland</option>
                                                <option value="India">India</option>
                                                <option value="Indonesia">Indonesia</option>
                                                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                                <option value="Iraq">Iraq</option>
                                                <option value="Ireland">Ireland</option>
                                                <option value="Isle of Man">Isle of Man</option>
                                                <option value="Israel">Israel</option>
                                                <option value="Italy">Italy</option>
                                                <option value="Jamaica">Jamaica</option>
                                                <option value="Japan">Japan</option>
                                                <option value="Jersey">Jersey</option>
                                                <option value="Jordan">Jordan</option>
                                                <option value="Kazakhstan">Kazakhstan</option>
                                                <option value="Kenya" selected="selected">Kenya</option>
                                                <option value="Kiribati">Kiribati</option>
                                                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                                <option value="Korea, Republic of">Korea, Republic of</option>
                                                <option value="Kuwait">Kuwait</option>
                                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                                <option value="Latvia">Latvia</option>
                                                <option value="Lebanon">Lebanon</option>
                                                <option value="Lesotho">Lesotho</option>
                                                <option value="Liberia">Liberia</option>
                                                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                                <option value="Liechtenstein">Liechtenstein</option>
                                                <option value="Lithuania">Lithuania</option>
                                                <option value="Luxembourg">Luxembourg</option>
                                                <option value="Macao">Macao</option>
                                                <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                                <option value="Madagascar">Madagascar</option>
                                                <option value="Malawi">Malawi</option>
                                                <option value="Malaysia">Malaysia</option>
                                                <option value="Maldives">Maldives</option>
                                                <option value="Mali">Mali</option>
                                                <option value="Malta">Malta</option>
                                                <option value="Marshall Islands">Marshall Islands</option>
                                                <option value="Martinique">Martinique</option>
                                                <option value="Mauritania">Mauritania</option>
                                                <option value="Mauritius">Mauritius</option>
                                                <option value="Mayotte">Mayotte</option>
                                                <option value="Mexico">Mexico</option>
                                                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                                <option value="Moldova, Republic of">Moldova, Republic of</option>
                                                <option value="Monaco">Monaco</option>
                                                <option value="Mongolia">Mongolia</option>
                                                <option value="Montenegro">Montenegro</option>
                                                <option value="Montserrat">Montserrat</option>
                                                <option value="Morocco">Morocco</option>
                                                <option value="Mozambique">Mozambique</option>
                                                <option value="Myanmar">Myanmar</option>
                                                <option value="Namibia">Namibia</option>
                                                <option value="Nauru">Nauru</option>
                                                <option value="Nepal">Nepal</option>
                                                <option value="Netherlands">Netherlands</option>
                                                <option value="Netherlands Antilles">Netherlands Antilles</option>
                                                <option value="New Caledonia">New Caledonia</option>
                                                <option value="New Zealand">New Zealand</option>
                                                <option value="Nicaragua">Nicaragua</option>
                                                <option value="Niger">Niger</option>
                                                <option value="Nigeria">Nigeria</option>
                                                <option value="Niue">Niue</option>
                                                <option value="Norfolk Island">Norfolk Island</option>
                                                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                                <option value="Norway">Norway</option>
                                                <option value="Oman">Oman</option>
                                                <option value="Pakistan">Pakistan</option>
                                                <option value="Palau">Palau</option>
                                                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                                <option value="Panama">Panama</option>
                                                <option value="Papua New Guinea">Papua New Guinea</option>
                                                <option value="Paraguay">Paraguay</option>
                                                <option value="Peru">Peru</option>
                                                <option value="Philippines">Philippines</option>
                                                <option value="Pitcairn">Pitcairn</option>
                                                <option value="Poland">Poland</option>
                                                <option value="Portugal">Portugal</option>
                                                <option value="Puerto Rico">Puerto Rico</option>
                                                <option value="Qatar">Qatar</option>
                                                <option value="Reunion">Reunion</option>
                                                <option value="Romania">Romania</option>
                                                <option value="Russian Federation">Russian Federation</option>
                                                <option value="Rwanda">Rwanda</option>
                                                <option value="Saint Helena">Saint Helena</option>
                                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                <option value="Saint Lucia">Saint Lucia</option>
                                                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                                <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                                                <option value="Samoa">Samoa</option>
                                                <option value="San Marino">San Marino</option>
                                                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                                <option value="Saudi Arabia">Saudi Arabia</option>
                                                <option value="Senegal">Senegal</option>
                                                <option value="Serbia">Serbia</option>
                                                <option value="Seychelles">Seychelles</option>
                                                <option value="Sierra Leone">Sierra Leone</option>
                                                <option value="Singapore">Singapore</option>
                                                <option value="Slovakia">Slovakia</option>
                                                <option value="Slovenia">Slovenia</option>
                                                <option value="Solomon Islands">Solomon Islands</option>
                                                <option value="Somalia">Somalia</option>
                                                <option value="South Africa">South Africa</option>
                                                <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                                                <option value="Spain">Spain</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                                <option value="Sudan">Sudan</option>
                                                <option value="Suriname">Suriname</option>
                                                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                                <option value="Swaziland">Swaziland</option>
                                                <option value="Sweden">Sweden</option>
                                                <option value="Switzerland">Switzerland</option>
                                                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                                <option value="Tajikistan">Tajikistan</option>
                                                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                                <option value="Thailand">Thailand</option>
                                                <option value="Timor-leste">Timor-leste</option>
                                                <option value="Togo">Togo</option>
                                                <option value="Tokelau">Tokelau</option>
                                                <option value="Tonga">Tonga</option>
                                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                                <option value="Tunisia">Tunisia</option>
                                                <option value="Turkey">Turkey</option>
                                                <option value="Turkmenistan">Turkmenistan</option>
                                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                <option value="Tuvalu">Tuvalu</option>
                                                <option value="Uganda">Uganda</option>
                                                <option value="Ukraine">Ukraine</option>
                                                <option value="United Arab Emirates">United Arab Emirates</option>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="United States">United States</option>
                                                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                                <option value="Uruguay">Uruguay</option>
                                                <option value="Uzbekistan">Uzbekistan</option>
                                                <option value="Vanuatu">Vanuatu</option>
                                                <option value="Venezuela">Venezuela</option>
                                                <option value="Viet Nam">Viet Nam</option>
                                                <option value="Virgin Islands, British">Virgin Islands, British</option>
                                                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                                <option value="Wallis and Futuna">Wallis and Futuna</option>
                                                <option value="Western Sahara">Western Sahara</option>
                                                <option value="Yemen">Yemen</option>
                                                <option value="Zambia">Zambia</option>
                                                <option value="Zimbabwe">Zimbabwe</option>
                                            </select>
                                        </div>
                                    </div>
            
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="city">City<span class="text-danger">*</span></label>
                                            <input type="text" name="city" id="city" class="form-control" required="required" placeholder="city">
                                        </div>
                                    </div>
            
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="postal-code">Postal Code</label>
                                            <input type="text" name="postal_code" id="postal-code" class="form-control" placeholder="postal code">
                                        </div>
                                    </div>
                                </div>
            
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="phone">Telephone<span class="text-danger">*</span></label>
                                            <input type="text" name="phone" id="phone" class="form-control" required="required" placeholder="telephone">
                                        </div>
                                    </div>
            
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="fax">Fax</label>
                                            <input type="text" name="fax" id="fax" class="form-control" placeholder="fax">
                                        </div>
                                    </div>
            
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="email">Email<span class="text-danger">*</span></label>
                                            <input type="text" name="email" id="email" class="form-control" required="required" placeholder="email">
                                        </div>
                                    </div>
                                </div>
            
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="occupation">Primary Occupation<span class="text-danger">*</span></label>
                                            <input type="text" name="occupation" id="occupation" class="form-control" required="required" placeholder="primary occupation">
                                        </div>
                                    </div>
            
                                   
                                </div>
                            </div>
            
                            <div class="card-footer">
                                <button type="button" class = "step-2-button btn btn-outline-info float-right">Next</button>
                            </div>
                        </div>            
                    </div>
            
                    <div class="tab-pane fade" id="step-2" role="tabpanel" aria-labelledby="step-2">
                        <div class="card my-5">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <h2 class="text-center">EDUCATION</h2>
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-sm-12">
                                        <p class="mb-3">(i) Level of academic qualification <span class="text-danger">**</span></p>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr style="background-color: #005DAE; color: white">
                                                    <th>Year Awarded</th>
                                                    <th>Degree/Certificate</th>
                                                    <th>Institution</th>
                                                </tr>
                                            </thead>
            
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <input type="text" name="academic_year[]" placeholder="year awarded" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_degree[]" placeholder="degree/certificate" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="academic_year[]" placeholder="year awarded" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_degree[]" placeholder="degree/certificate" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="academic_year[]" placeholder="year awarded" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_degree[]" placeholder="degree/certificate" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="academic_year[]" placeholder="year awarded" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_degree[]" placeholder="degree/certificate" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="academic_year[]" placeholder="year awarded" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_degree[]" placeholder="degree/certificate" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="academic_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table> 
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-sm-12">
                                        <p class="mb-3">(ii) Arbitration training <span class="text-danger">**</span></p>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr style="background-color: #005DAE; color: white">
                                                    <th>Year</th>
                                                    <th>Nature of training</th>
                                                    <th>Institution</th>
                                                </tr>
                                            </thead>
            
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <input type="text" name="training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-sm-12">
                                        <p class="mb-3">(iii) Other training in dispute resolution <span class="text-danger">**</span></p>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr style="background-color: #005DAE; color: white">
                                                    <th>Year</th>
                                                    <th>Nature of training</th>
                                                    <th>Institution</th>
                                                </tr>
                                            </thead>
            
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <input type="text" name="other_training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_other_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="other_training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="other_training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_other_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="other_training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="other_training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_other_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="other_training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="other_training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_other_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="other_training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
            
                                                <tr>
                                                    <td>
                                                        <input type="text" name="other_training_year[]" placeholder="year attended" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="nature_of_other_training[]" placeholder="nature" id="" class="form-control">
                                                    </td>
            
                                                    <td>
                                                        <input type="text" name="other_training_institution[]" placeholder="institution" id="" class="form-control">
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
            
                                        <p class="mt-5">
                                            <span class="text-danger">*  </span> You will be requested to provide proof of qualification and training during approval.<br>
                                            <span class="text-danger">**</span> (If you have been involved in such training as a facilitator, trainer or instructor, you will be requested to describe your role.)
                                        </p>
                                    </div>
                                </div>
                            </div>
            
                            <div class="card-footer">
                                <button type="button" class = "step-1-button btn btn-outline-secondary">Previous</button>
                                <button type="button" class = "step-3-button btn btn-outline-info float-right">Next</button>
                            </div>
                        </div>
            
                        
                    </div>
            
                    <div class="tab-pane fade" id="step-3" role="tabpanel" aria-labelledby="step-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <h2 class="text-center">ARBITRATION EXPERIENCE</h2>
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-sm-12">
                                        <p class="mb-3">(a) Indicate the number of Arbitrations, if any, that you have acted and the role in the areas specified in the table below;</p>
            
                                        <table class="table table-bordered table-responsive">
                                            <thead>
                                                <tr style="background-color: #005DAE; color: white">
                                                    <th></th>
                                                    <th>Commercial</th>
                                                    <th>Construction</th>
                                                    <th>Investor/State</th>
                                                    <th>Other(Special)</th>
                                                </tr>
                                            </thead>
            
                                            <tbody>
                                                <tr>
                                                    <th>Sole Arbitrator</th>
            
                                                    <td><input type="number" value = "0" min = "0"  name="sole_commercial" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="sole_construction" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="sole_investor" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="sole_other" placeholder="" class="form-control"></td>
                                                </tr>
            
                                                <tr>
                                                    <th>Member arbitrator panel</th>
            
                                                    <td><input type="number" value = "0" min = "0"  name="member_commercial" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="member_construction" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="member_investor" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="member_other" placeholder="" class="form-control"></td>
                                                </tr>
            
                                                <tr>
                                                    <th>Counsel/Agent</th>
            
                                                    <td><input type="number" value = "0" min = "0" name="counsel_commercial" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="counsel_construction" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="counsel_investor" placeholder="" class="form-control"></td>
                                                    <td><input type="number" value = "0" min = "0"  name="counsel_other" placeholder="" class="form-control"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-sm-12">
                                        <p class="mb-3">(b) Provide a brief outline/profile of disputes you have handled as an arbitrator;</p>
            
                                        <table class="table table-bordered table-responsive">
                                            <thead>
                                                <tr style="background-color: #005DAE; color: white">
                                                    <td>Type of dispute (e.g Breach of Contract)</td>
                                                    <td>Issues</td>
                                                    <td>Value of dispute</td>
                                                    <td>Nature of evidence <span class="text-danger">*</span></td>
                                                    <td>Duration of dispute</td>
                                                </tr>
                                            </thead>
            
                                            <tbody>
                                                <tr>
                                                    <td><textarea name="dispute_type[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_issue[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_value[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_evidence[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_duration[]" class="form-control"></textarea></td>
                                                </tr>
            
                                                <tr>
                                                    <td><textarea name="dispute_type[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_issue[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_value[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_evidence[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_duration[]" class="form-control"></textarea></td>
                                                </tr>
            
                                                <tr>
                                                    <td><textarea name="dispute_type[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_issue[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_value[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_evidence[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_duration[]" class="form-control"></textarea></td>
                                                </tr>
            
                                                <tr>
                                                    <td><textarea name="dispute_type[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_issue[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_value[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_evidence[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_duration[]" class="form-control"></textarea></td>
                                                </tr>
            
                                                <tr>
                                                    <td><textarea name="dispute_type[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_issue[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_value[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_evidence[]" class="form-control"></textarea></td>
                                                    <td><textarea name="dispute_duration[]" class="form-control"></textarea></td>
                                                </tr>
                                            </tbody>
                                        </table>
            
                                        <p class="mt-5">
                                            <span class="text-danger">*</span> e.g. documentary, oral, witnesses.
                                        </p>
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="">c) Number of years you have acted as an Arbitrator? (Please attach a brief resume/curriculum vitae/profile).</label>
                                            <input type="number" value = "0" min = "0" name="years_acted" class="form-control">
                                        </div>
            
                                        <div class="form-group">
                                            <label for="">d) Are you a certified/accredited Arbitrator or listed in the panel of any other arbitral/Arbitration institution?</label>
                                            <div class="radio">
                                                <input type="radio" name="certified" value = "1" id=""> Yes
                                                <input type="radio" name="certified" value = "0" checked="" id=""> No
                                            </div>
                                        </div>
            
                                        <div class="form-group">
                                            <label for="">If yes, provide particulars</label>
                                            <input type="text" name="certified_particulars" class="form-control">
                                        </div>
            
                                        <div class="form-group">
                                            <label for="">e) Is arbitration your primary (full-time) practice?</label>
                                            <div class="radio">
                                                <input type="radio" name="primary_practice" value = "1" id=""> Yes
                                                <input type="radio" name="primary_practice" value = "0" checked="" id=""> No
                                            </div>
                                        </div>
            
                                        <div class="form-group">
                                            <label for="">f) Are you willing to be appointed as an Emergency Arbitrator?</label>
                                            <div class="radio">
                                                <input type="radio" name="willing_to_be_emergency_arbitrator" value = "1" id=""> Yes
                                                <input type="radio" name="willing_to_be_emergency_arbitrator" value = "0" checked="" id=""> No
                                            </div>
                                        </div>
            
                                        <div class="form-group">
                                            <label for="">If yes, please provide contact details for appointment as an emergency arbitrator.</label>
                                        </div>
            
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Tel no</label>
                                                    <input type="text" name="emergency_tel_no" class="form-control">
                                                </div>
                                            </div>
            
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Email address</label>
                                                    <input type="text" name="emergency_email" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Physical address</label>
                                                    <input type="text" name="emergency_physical_address" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
            
                            <div class="card-footer">
                                <button type="button" class="step-2-button btn btn-outline-secondary">Previous</button>
                                <button type="button" class="step-4-button btn btn-outline-success float-right">Next</button>
                            </div>
                        </div>
                    </div>
            
                    <div class="tab-pane fade" id="step-4" role="tabpanel" aria-labelledby="step-4">
                        <div class="card">
                            <div class="card-body">            
                                <div class="row">
                                    <div class="col-12">
                                        <h2 class="text-center">OTHER INFORMATION</h2>
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-sm-12">
                                  
                                        <div class="form-group">
                                            <label for="">a) Outline any other relevant experience or provide any other information which supports your application (including where your Arbitration experience involves disputes of an international character).</label>
                                            <textarea name="relevant_expereince" id="" cols="30" rows="10" class="form-control"></textarea>
                                        </div>
            
                                        <div class="form-group">
                                            <label for="">b) What is your preferred area(s) of practice as an Arbitrator?</label>
                                            <textarea name="preferred_areas" id="" cols="30" rows="10" class="form-control"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label for="">c) Curriculum Vitae (CV)</label><br>
                                            <input type="file" name="cv" id="cv" accept=".pdf,.doc,.docx" required="">
                                        </div>
                                    </div>
                                </div>
                            </div>
            
                            <div class="card-footer">
                                <button type="button" class = "step-3-button btn btn-outline-secondary">Previous</button>
                                <button type="button" class = "step-5-button btn btn-outline-success float-right">Next</button>
                            </div>
                        </div>
                    </div>
            
                    <div class="tab-pane fade" id="step-5" role="tabpanel" aria-labelledby="step-5">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <h2 class="text-center">DECLARATION</h2>
                                    </div>
                                </div>
            
                                <div class="row mt-5">
                                    <div class="col-sm-12">
                                  
                                        <p>
                                            I understand the Nairobi Centre for International Arbitration does not provide employment for any Arbitrator. I also understand the decision to nominate or appoint an Arbitrator or Arbitrators to any Arbitration referred to Nairobi Centre for International Arbitration is within the exclusive discretion of the Nairobi Centre for International Arbitration.
                                        </p>
            
                                        <p>
                                            I hereby declare that the information provided herein is complete and accurate. I understand that a false statement may disqualify my application from consideration and I hereby give my consent to a personal investigation in connection with this application for NCIA Arbitrator Panel Status.
                                        </p>
            
                                        <p>
                                            I agree, if accredited to NCIA Arbitrator Panel Status, to be bound by the terms and conditions applicable to NCIA Arbitrator Panel Status and to comply with the Arbitrator Panel Status Standard, the NCIA Code of Conduct for Arbitrators, Nairobi Centre for International Arbitration (Arbitration) Rules, 2015 or there amendments or alterations from time to time and any other professional or legal requirement to which I am subject.
                                        </p>
            
                                        <p><label for=""><input type="checkbox" name="consent" id="" value = "consent"></label> Check this box if you agree with all the above</p>
                                        
                                    </div>
                                </div>
                            </div>
            
                            <div class="card-footer">
                                <button type="button" class = "step-4-button btn btn-outline-secondary">Previous</button>
                                <button type="submit" name = "register" class = "btn btn-outline-success float-right">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
                
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ncia\resources\views/pages/register-arbitrator.blade.php ENDPATH**/ ?>