		
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					

					<br><p>Regards, <br> {{ config('app.name') }}</p>

					<br> <p><small class="text-muted">This is a system generated message, please do not reply.</small></p>	
				</div>
			</div>
		</div>
			
	</body>
</html>