<style type="text/css">

	table > tr > th {
		text-align: left !important;
	}
	
</style>